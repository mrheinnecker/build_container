#'\code{get_package_tables} get a list of all tables of a package
#'@param pkgName package name
#'@return ordered list of package data frames
#'@export
get_package_tables = function(pkgName) {
  pkgEnv = paste0('package:',pkgName)
  eval(parse(text=paste("library(",pkgName,")")))
  pkgDataTables = tibble(varname=ls(name = pkgEnv)) %>% rowwise() %>% mutate(class=paste0(class(eval(parse(text=varname))),collapse = ' ')) %>% filter(str_detect(class,'data\\.frame')) %>% {.$varname}
  ret = map(pkgDataTables,function(varname) {
    get(varname,as.environment(pkgEnv))
  })
  names(ret) = pkgDataTables
  return(ret[order(names(ret))])
}

#'\code{save_package_tables} save all package tables as RData objects to the specified directory
#'@param pkgName package name
#'@param file target RData file
#'@export
save_package_tables = function(pkgName, file) {
  pkgEnv = paste0('package:',pkgName)
  eval(parse(text=paste("library(",pkgName,")")))
  pkgDataTables = tibble(varname=ls(name = pkgEnv)) %>% mutate(class=paste0(class(eval(parse(text=varname))),collapse = ' ')) %>% filter(str_detect(class,'data\\.frame')) %>% {.$varname}
  save(list=pkgDataTables, file=file, envir=as.environment(pkgEnv))
}

