#'\code{knowledgeConnector_connect} tunnels to the podest-worker server and connects to the Knowledge Connector database. The variable values need to be defined in podestTools_init.R
#'@param private_key path to the private key which can be used to connect to the podest-worker server; default: key of the tmo_data user
#'@param port port which is used to create a tunnel to the podest-worker server
#'@return list(con, pid)
#'@export
knowledgeConnector_connect = function(
    private_key = TMO$tmo_data_private_key,
    port = TMO$podest_worker_server_tunnel_port
){
  kc_host = TMO$kc_host
  kc_name = TMO$kc_database_name
  kc_port = TMO$kc_port
  kc_user = "tmo"
  kc_password = TMO$kc_database_password

  if(Sys.info()["nodename"] == "podest-worker"){


    pid = ""

    con <- DBI::dbConnect(
      drv=RPostgres::Postgres(),
      host=kc_host,
      port=port,
      user=kc_user,
      password=kc_password,
      dbname=kc_name
    )
  } else {

    pid = sys::exec_background(
      'ssh',
      c('-i',private_key,
        '-N',
        '-L', paste0(port,':127.0.0.1:5555'), 'ubuntu@10.128.130.167'), std_out = F, std_err = F)

    Sys.sleep(5)

    con <- DBI::dbConnect(
      drv=RPostgres::Postgres(),
      host="127.0.0.1",
      port=port,
      user=kc_user,
      password=kc_password,
      dbname=kc_name
    )
  }

  return(list(con=con, pid=pid))
}


#'\code{knowledgeConnector_disconnect} stops the tunnel and destroys the sql connection
#'@param knowledgeConnector_con knowledgeConnector_connect object
#'@export
knowledgeConnector_disconnect = function(knowledgeConnector_con) {
  DBI::dbDisconnect(knowledgeConnector_con$con)
  tools::pskill(knowledgeConnector_con$pid)
}

#'\code{get_knowledgeConnector_table} reads the specified table from the knowledge connector database
#'@param target_table name of the table
#'@param schema name of the schema, select from "kc" or "mtb"
#'@param knowledgeConnector_con a connection to the Knowledge Connector database
#'@param private_key path to private key file to use for the connection
#'@param port port to use for the connection
#'@return data frame
#'@export
get_knowledgeConnector_table = function(
    target_table,
    schema = "kc",
    knowledgeConnector_con,
    private_key = TMO$tmo_data_private_key,
    port = TMO$podest_worker_server_tunnel_port
){
  # if no knowledgeConnector_con object was passed to the function, create a connection to the database
  if(missing(knowledgeConnector_con)) {
    knowledgeConnector_return_con = knowledgeConnector_connect(private_key = private_key, port = port)
  # if a knowledgeConnector_con object was passed, save it under the same variable
  } else {
    knowledgeConnector_return_con = knowledgeConnector_con
  }
  tryCatch({
    # get the database connection from the knowledgeConnector_return_con object
    con = knowledgeConnector_return_con$con

    # set the searchpath to schema
    DBI::dbExecute(con, paste0('SET search_path TO "', schema,'"'))

    # setup table query
    table_query = paste0('SELECT * FROM ', target_table)

    # get the requested table from the database
    output = DBI::dbGetQuery(con, table_query) %>% as_tibble()

    # if no knowledgeConnector_con object was passed to the function, disconnect the internally created connection
    if(missing(knowledgeConnector_con)) {
      knowledgeConnector_disconnect(knowledgeConnector_return_con)
    }

    # return output
    return(output)
  }, error = function(cond){
    if(missing(knowledgeConnector_con)) {
      knowledgeConnector_disconnect(knowledgeConnector_return_con)
    }
  })
}
