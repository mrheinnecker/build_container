# In this file we define make functions to download external sources if they are outdated

#'\code{make_podest_source} download external source data if it is outdated
#'@return nothing
#'@export
make_podest_source = function() {
  make_ncit.obo()
}

#'\code{make_ncit.obo} download ncit.obo "http://purl.obolibrary.org/obo/ncit.obo" to "/podest_source/ncit/ncit.obo" if outdated
#'@return nothing
#'@export
make_ncit.obo = function() {
  ncit_obo_uri <- "http://purl.obolibrary.org/obo/ncit.obo"
  ncit_obo_file = paste0(TMO$TMO_data_dir,"/podest_source/ncit/ncit.obo")

  # if ncit_obo_file is missing or outdated (date of last month)
  if(!file.exists(ncit_obo_file) | year(file.info(ncit_obo_file)$mtime) + month(file.info(ncit_obo_file)$mtime)/12 < year(today()) + month(today())/12) {
    download.file(ncit_obo_uri, ncit_obo_file)
    archive_file(ncit_obo_file)
    ncit_obo = ontologyIndex::get_OBO(ncit_obo_file, propagate_relationships = "is_a", extract_tags = c ("everything"))
    saveRDS(ncit_obo,paste0(TMO$TMO_data_dir,"/podest_source/ncit/ncit.obo.RDS"))
    archive_file(paste0(TMO$TMO_data_dir,"/podest_source/ncit/ncit.obo.RDS"))
  }
}
