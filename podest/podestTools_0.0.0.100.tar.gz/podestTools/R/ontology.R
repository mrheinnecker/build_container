#'\code{get_term_property_name} get property of node
#'@param ontology ontology_index object
#'@param property name of property (with value list)
#'@param name name of value
#'@param term Character value of term ID
#'@return character string
#'@export
get_term_property_name = function(ontology, term, property = 'property_value', name=NA) {
  p = map(term, function (t) {
    t = ontologyIndex::get_term_property(ontology=ontology, term=t, property_name=property) %>%
      str_subset(paste0('^',coalesce(name,'.+?'),' \"')) %>% str_replace(paste0('^',coalesce(name,''),' \"(.+?)\".+$'),'\\1')
  })
  return(p)
}
