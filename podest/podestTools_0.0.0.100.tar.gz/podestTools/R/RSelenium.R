# functions used to ease usage of RSelenium package for browser control
# authors: Simon Kreutzfeldt

#'\code{rs_firefox_start} start RSelenium firefox
#'@param url url to open
#'@param port port to use
#'@param windowSize.x width of window
#'@param windowSize.y height of window
#'@return rsDriver
#'@export
rs_firefox_start = function(url=NA, port=4567L, windowSize.x = 1280, windowSize.y = 1280) {
  system('taskkill /F /IM java.exe', show.output.on.console = F, ignore.stdout = T, ignore.stderr = T)
  system('taskkill /F /IM geckodriver.exe', show.output.on.console = F, ignore.stdout = T, ignore.stderr = T)
  system('taskkill /F /IM firefox.exe', show.output.on.console = F, ignore.stdout = T, ignore.stderr = T)
  wlog(paste("Starting Firefox portable on",TMO$ip))
  binary_file=paste0(TMO$TMO_data_dev_dir,'/tools/FirefoxPortable/App/Firefox64/firefox.exe')
  if (Sys.getenv('PATH') %>% str_detect('rtools')==F) {
    Sys.setenv('PATH' = paste0(Sys.getenv('PATH'),';',
                               TMO$TMO_data_dev_dir,'\\tools\\rtools40;',
                               TMO$TMO_data_dev_dir,'\\tools\\rtools40\\mingw64\\bin;',
                               TMO$TMO_data_dev_dir,'\\tools\\rtools40\\usr\\bin'))
  }
  fprof = RSelenium::makeFirefoxProfile(list(
    browser.startup.homepage = "http://www.google.de",
    browser.download.dir = str_replace_all(TMO$TMO_download_dir,'/','\\\\') %>% str_replace_all('\\\\','\\\\\\\\'),
    browser.download.useDownloadDir = TRUE,
    browser.download.manager.showWhenStarting = FALSE,
    browser.download.folderList = 2L,
    pdfjs.disabled = TRUE,
    browser.helperApps.neverAsk.saveToDisk = "application/octet-stream,application/pdf,application/zip,application/vnd.ms-excel,text/csv,text/plain"
  ))
  fprof$`moz:firefoxOptions` = list(binary = binary_file)
  rsDriverInstance = RSelenium::rsDriver(browser = "firefox", extraCapabilities = fprof, remoteServerAddr=TMO$ip, check=F, verbose = F, geckover = "0.30.0")

  rsDriverInstance$client$setTimeout(type="implicit", milliseconds = 10000)
  rsDriverInstance$client$navigate(url)
  if (str_detect(windowSize.x,'^[0-9]+$') & str_detect(windowSize.y,'^[0-9]+$')) rsDriverInstance$client$setWindowSize(windowSize.x, windowSize.y)
  return(rsDriverInstance)
}

#'\code{rs_quit} quit RSelenium  browser
#'@return success
#'@export
rs_quit = function(rs = get('rsDriverInstance')) {
  force(rs)
  rs$client$quit()
  ret = rs$server$stop()
  rm(rs)
  return(ret)
}

#'\code{rs_waitForElement} Search for an element on the page, starting from the document root. If it is not found, search is iterated TIMES times and we will wait WAIT ms before each iteration. The rsDriver object will be passed through and returned.
#'@param rs rsDriver object
#'@param value search expression (e.g. xpath)
#'@param using Locator scheme to use to search the element, available schemes: "class name", "css selector", "id", "name", "link text", "partial link text", "tag name", "xpath" . Defaults to 'xpath'. Partial string matching is accepted.
#'@return rs
#'@export
rs_waitForElement = function(rs, value, using="xpath", ...) {
  force(rs)
  fun = function() { length(rs$client$findElements(using = using, value = value))}
  repeat_function(fun, ...)
  return(rs)
}

#'\code{rs_clickElement} Search for an element on the page and click, starting from the document root. If it is not found, search is iterated TIMES times and we will wait WAIT ms before each iteration. The rsDriver object will be passed through and returned.
#'@param rs rsDriver object
#'@param value search expression (e.g. xpath)
#'@param using Locator scheme to use to search the element, available schemes: "class name", "css selector", "id", "name", "link text", "partial link text", "tag name", "xpath" . Defaults to 'xpath'. Partial string matching is accepted.
#'@return rs
#'@export
rs_clickElement = function(rs, value, using="xpath", ...) {
  force(rs)
  rs_waitForElement(rs=rs, value=value, using=using, ...)
  rs$client$findElement(using = using, value = value)$clickElement()
  return(rs)
}

#'\code{rs_typeInElement} Search for an element on the page and type into the text field. If it is not found, search is iterated TIMES times and we will wait WAIT ms before each iteration. The rsDriver object will be passed through and returned.
#'@param rs rsDriver object
#'@param value search expression (e.g. xpath)
#'@param using Locator scheme to use to search the element, available schemes: "class name", "css selector", "id", "name", "link text", "partial link text", "tag name", "xpath" . Defaults to 'xpath'. Partial string matching is accepted.
#'@param clearBefore clear text field before typing into it? T/F (Default: T)
#'@param typeList List of strings to by typed
#'@return rs
#'@export
rs_typeInElement = function(rs, value, typeList, clearBefore=T, using="xpath", ...) {
  force(rs)
  rs_waitForElement(rs=rs, value=value, using=using, ...)
  if (clearBefore==T) rs$client$findElement(using = using, value = value)$clearElement()
  rs$client$findElement(using = using, value = value)$sendKeysToElement(typeList)
  return(rs)
}

#'\code{rs_executeScript} Execute script on rsDRiver
#'@param rs rsDriver object
#'@param script script to execute
#'@return rs
#'@export
rs_executeScript = function(rs, script, ...) {
  force(rs)
  rs$client$executeScript(script)
  return(rs)
}

#'\code{rs_callAfterDownload} call function after downloading a certain file
#'@param rs rsDriver object
#'@param download_dir path to the downloaded directory
#'@param file_regex regex for downloaded file
#'@param func = function to call. The result of function will be used as return value
#'@param timeout = time to wait for download [s], default:3600
#'@return rs
#'@export
rs_callAfterDownload = function(rs, download_dir = paste0(TMO$TMO_data_dir,'/Downloads'), file_regex, func = function(file) {print(paste(file,'successfully downloaded.'))}, timeout = 3600) {
  force(rs)
  for (i in floor(1:(timeout / 6))) {
    dfile = list.files(path=download_dir, pattern=file_regex, full.names = T) %>% file.info() %>% as_tibble(rownames = "file") %>%
      filter(size>0) %>% arrange(mtime) %>% first() %>% .[1]
    if (!is.na(dfile)) {
      func(normalizePath(dfile, winslash = '/'))
      break
    } else if (i==floor(timeout / 6)) {
      print(paste("No matching file found during waiting period."))
      quit(save = F)
    } else {
      print(paste("Waiting for downloaded file (",file_regex,") since",i*6/60,"minutes. Will stop after 60 minutes."))
      Sys.sleep(6)
    }
  }
  return(rs)
}

