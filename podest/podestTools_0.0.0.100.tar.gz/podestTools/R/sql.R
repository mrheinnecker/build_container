#'\code{sql_tableInfo_update} insert or update podest/meta/tableInfo
#'@param con connection
#'@param schema sql schema
#'@param table table data frame
#'@param tableName table name to use (optional)
#'@param dataDate date when the data was generated
#'@param updateTime date and time when the table was updated
#'@param updatedBy Who updated the table lthe last time?
#'@export
sql_tableInfo_update = function(con = sql_con(), schema, table, dataDate=NA_Date_, updateTime = Sys.time(), updatedBy="unknown", tableName) {
  if (missing(tableName)) tableName=as.character(substitute(table))
  DBI::dbExecute(con,paste0('SET search_path TO "meta"'))
  newline = tibble(schema=schema, table=tableName, dataDate = as.Date(dataDate), updateTime = as.POSIXct(updateTime), updatedBy=updatedBy, nrow = nrow(table), ncol = ncol(table))
  new_tableInfo = if (DBI::dbExistsTable(con, 'tableInfo')) {
    tbl(con, dbplyr::in_schema('meta', 'tableInfo')) %>% collect() %>% rows_upsert(newline, by=c('schema', 'table'))
  } else {
    newline
  }

  DBI::dbWriteTable(
    con = con,
    value = new_tableInfo, name = 'tableInfo',
    temporary = FALSE, overwrite = TRUE
  )
  return(con)
}


#'\code{sql_con} create sql connection object
#'@param command sql command to execulte
#'@param sql_server name/IP of sql server, default TMO$sql_server
#'@param sql_server_port port of sql server, default: 5432
#'@param sql_server_db database to connect, default: TMO$sql_server_db
#'@param sql_server_login login of connection, default TMO$sql_server_login
#'@param sql_server_password password of connection, default TMO$sql_server_password
#'@param sql_server_ssl_mode ssl_mode, default 'prefer'
#'@return DBI::dbConnect object
#'@export
sql_con = function( sql_server = TMO$sql_server,
                    sql_server_port = 5432,
                    sql_server_db = TMO$sql_server_db,
                    sql_server_login = TMO$sql_server_login,
                    sql_server_password = TMO$sql_server_password,
                    sql_server_ssl_mode = TMO$sql_server_ssl

) {
  DBI::dbConnect(RPostgres::Postgres(), host = sql_server, port = sql_server_port, dbname = sql_server_db, user = sql_server_login, password = sql_server_password, sslmode = sql_server_ssl_mode) %>% suppressWarnings()
}

#'\code{sql_dis} disconnect from sql connection object
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@return result
#'@export
sql_dis = function(con) { return(DBI::dbDisconnect(con))}

#'\code{sql_execute} execute SQL on sql server
#'@param command sql command to execulte
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param disconnect disconnect con when finished?, default FALSE
#'@export
sql_execute = function(con, command, disconnect=F) {
  DBI::dbExecute(con,command)
  if (disconnect) sql_dis(con)
  return(con)
}

#'\code{sql_create_table} create tables on sql server
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param df data frame
#'@param df_name data frame name
#'@param schema schema name
#'@param index_cols index columns (default: all)
#'@param primary_keys primary key columns (default: none)
#'@param if_exists What should be done if the table already exists? (drop_cascade, drop, clean, stop. Default: stop). drop_cascade = drop table even if foreign keys reference to it.
#'@param comment A comment to write to the SQL database
#'@param colComments A list of comments to the colums, e.g. list(colname='comment abc')
#'@param conPassword If you tell me the sql con password, I can use psql upload which is about x4 faster than standard upload
#'@param tempdir tempdir if psql is used for upload
#'@param dataDate date when the data was generated
#'@param updatedBy Who updated the table the last time?
#'@export
sql_create_table = function(con = sql_con(),
                            df,
                            df_name = str_remove(deparse(substitute(df)),'\\[.+$'),
                            schema = "public",
                            index_cols = colnames(df),
                            primary_keys=NA,
                            if_exists = "stop",
                            comment,
                            colComments,
                            conPassword,
                            tempdir,
                            dataDate=NA,
                            updatedBy = "unknown"
) {
  conInfo = DBI::dbGetInfo(con)
  DBI::dbExecute(con,paste0('CREATE SCHEMA IF NOT EXISTS "', schema,'"'))
  DBI::dbExecute(con,paste0('SET search_path TO "', schema,'"'))
  tableExists=F
  if (DBI::dbExistsTable(con, DBI::Id(schema=schema, table=df_name))) {
    tableExists=T
    if (if_exists=="drop_cascade") {
      wlog(paste0('Dropping table ',df_name))
      DBI::dbExecute(con,paste0('DROP TABLE IF EXISTS "',schema,'"."', df_name,'" CASCADE'))
      tableExists=F
    } else if (if_exists=="drop") {
      wlog(paste0('Dropping table ',df_name))
      DBI::dbExecute(con,paste0('DROP TABLE IF EXISTS "',schema,'"."', df_name,'"'))
      tableExists=F
    } else if (if_exists=="clean") {
      wlog(paste0('Truncating table ',df_name))
      DBI::dbExecute(con,paste0('TRUNCATE TABLE "',schema,'"."', df_name,'" ; '))
    } else {
      wlog(type = 'error', text = paste0("SQL table ",df_name," already exists"))
    }
  }
  # create table and set columns
  if (!tableExists) {
    DBI::dbWriteTable(
      conn = con,
      name = df_name,
      value = as.data.frame(df[0,]),
      temporary = FALSE,
      overwrite = T
    )
  }
  DBI::dbExecute(con,paste0('alter table "',schema,'"."',df_name,'" SET (parallel_workers = 6)'))

  max_rows = 10000000 # * ceiling(20 / ncol(df))
  n_rows = nrow(df)
  for (i in 0:floor((n_rows - 1)/max_rows)) {
    start_row = i * max_rows + 1
    end_row = ifelse((i+1) * max_rows < n_rows, (i+1)*max_rows, n_rows)
    # upload data - use psql if I got conList because it is factor >4 faster than DBI::dbWriteTable
    if (missing(conPassword)) {
      wlog(paste0("Uploading (dbWriteTable) to SCHEMA ",schema,": TABLE '",df_name,"'",' rows ', start_row,' to ', end_row))
      DBI::dbWriteTable(
        conn = con,
        name = df_name,
        value = df[start_row:end_row,],
        temporary = FALSE,
        overwrite = FALSE,
        append = TRUE
      )
    } else {
      wlog(paste0("Uploading (psql) to SCHEMA ",schema,": TABLE '",df_name,"'",' rows ', start_row,' to ', end_row))
      tmpfile = if (missing(tempdir)) tempfile(fileext = '.csv') else tempfile(fileext = '.csv', tmpdir = tempdir)
      if (!dir.exists(dirname(tmpfile))) dir.create(dirname(tmpfile), recursive = T)
      data.table::fwrite(df[start_row:end_row,], tmpfile)
      command = paste0("cat '",tmpfile,"' | psql -c \"\\copy \\\"",schema,"\\\".\\\"",df_name,"\\\" FROM STDIN WITH CSV HEADER\" postgresql://",conInfo$username,":",conPassword,"@",conInfo$host,":",conInfo$port,"/",conInfo$dbname)
      system(command)
      file.remove(tmpfile)
    }
  }
  if (tableExists==F) {
    if (!is.na(primary_keys[[1]])) {
      wlog(paste0('Creating primary key for columns "',paste0(primary_keys, collapse = '", "'),'"'))
      DBI::dbExecute(con,paste0('alter table "',schema,'"."',df_name,'" add constraint "',df_name,'_pk" primary key ("',paste0(primary_keys, collapse = '", "'),'")'))
    }
    index_cols %>% walk(function(col) {
      wlog(paste0('Creating index for "',col,'"'))
      command = paste0('create index "',df_name,'.',col,'_idx" on "',schema,'"."',df_name,'" ("',col,'")')
      DBI::dbExecute(con,command)
    }) %>% invisible()

  }
  if(!missing(comment)) {
    wlog('Setting comment')
    DBI::dbExecute(con,paste0("comment on table \"",schema,"\".\"",df_name,"\" is '",comment,"';"))
  }

  # set column comments
  if(!missing(colComments)) {
    wlog('Setting column comments')
    walk2(names(colComments), colComments, function(colname, com) {
    DBI::dbExecute(con, paste0("COMMENT ON COLUMN \"",schema,"\".\"", df_name, "\".\"", colname, "\" IS '",com,"'"))
    })
  }

  sql_tableInfo_update(con = con, schema = schema, table = df, tableName = df_name, dataDate = dataDate, updatedBy = updatedBy)

  if(missing(con)) {
    sql_dis(con)
  } else {
    return(con)
  }
}





#'\code{sql_set_foreign_key} set foreign key for table on sql server
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param sourceSchema source schema name
#'@param sourceTable source table
#'@param sourceCols character vector of source (foreign) key columns
#'@param targetSchema target schema name (default: sourceSchema)
#'@param targetTable target table
#'@param targetCols character vector of target key columns (default: sourceCols)
#'@param if_exists What should be done if the foreign key already exists? (skip, overwrite, Default: skip).
#'@export
sql_set_foreign_keys = function(con,
                                sourceSchema,
                                sourceTable,
                                sourceCols,
                                targetSchema,
                                targetTable,
                                targetCols,
                                ifExists = "skip"
) {
  if (missing(targetSchema)) targetSchema=sourceSchema
  if (missing(targetCols)) targetCols=sourceCols
  constraintName_full = paste0('FK_',sourceSchema,'_',sourceTable,'_',paste(sourceCols, collapse = '_'),'_',targetSchema,'_',targetTable,'_',paste(targetCols, collapse = '_'))
  constraintName = paste0('FK_',str_sub(sourceSchema,1,6),'_',str_sub(sourceTable,1,9),'_',str_sub(paste(sourceCols, collapse = '_'),1,9),'_',str_sub(targetSchema,1,6),'_',str_sub(targetTable,1,9),'_',str_sub(paste(targetCols, collapse = '_'),1,9),'_',str_sub(digest::digest(constraintName_full,algo='md5', serialize = FALSE),1,5))
  constraintExists = tbl(con, dbplyr::in_schema('information_schema','referential_constraints')) %>% filter(constraint_name == constraintName) %>% collect() %>% nrow() > 0
  if (constraintExists & ifExists=="skip") {
    wlog(paste0('Foreign key ',constraintName,' already exists - skipping.'))
  } else {
    DBI::dbExecute(con,'SET client_min_messages TO WARNING;')
    DBI::dbExecute(con,paste0('alter table "',sourceSchema,'"."',sourceTable,'" drop constraint if exists "',constraintName,'"'))
    wlog(paste0('Creating foreign key constrains for table ',sourceTable,' (col: ',paste(sourceCols, collapse = ','),') referencing ',targetSchema,'.',targetTable,' (',paste(targetCols, collapse = ', '),')'))
    DBI::dbExecute(con,paste0('alter table "',sourceSchema,'"."',sourceTable,'" add constraint "',constraintName,'" foreign key ("',paste(sourceCols, collapse = '", "'),'") references "',targetSchema,'"."',targetTable,'" ("',paste(targetCols, collapse = '", "'),'")'))
  }
  return(con)
}

#'\code{sql_set_primary_key} set primary key(s) for table on sql server
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param table name of table
#'@param primary_keys character vector of primary key columns
#'@export
sql_set_primary_key = function(con,
                               schema,
                               table,
                               primary_keys
) {
  wlog(paste0('Creating primary key for columns "',paste0(primary_keys, collapse = '", "'),'"'))
  DBI::dbExecute(con,paste0('alter table "',schema,'"."',table,'" add constraint "',table,'_pk" primary key ("',paste0(primary_keys, collapse = '", "'),'")'))
  return(con)
}

#'\code{sql_set_index} set (primary)combined) index for table on sql server
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param table name of table
#'@param index_cols character vector of combined index cols
#'@export
sql_set_index = function(con,
                         schema,
                         table,
                         index_cols
) {
  wlog(paste0('Creating (combined) index for columns "',paste0(index_cols, collapse = '", "'),'"'))
  DBI::dbExecute(con,paste0('create index ',table,'_',paste0(index_cols, collapse = '_'),'_index on "',schema,'"."',table,'" ("',paste0(index_cols, collapse = '", "'),'")'))
  return(con)
}

#'\code{sql_create_tables} create tables on sql server
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param dfs list of data frames
#'@param schema schema name
#'@param disconnect disconnect con when finished?, default FALSE
#'@export
sql_create_tables = function(con, dfs, schema, disconnect=F) {
  DBI::dbExecute(con,paste('CREATE SCHEMA IF NOT EXISTS', schema))
  DBI::dbExecute(con, paste("SET search_path TO ", schema))
  max_rows = 10000000
  map2(dfs,names(dfs), function(df, name) {
    n_rows = nrow(df)
    DBI::dbExecute(con,paste('DROP TABLE IF EXISTS', name))
    for (i in 0:floor((n_rows - 1)/max_rows)) {
      start_row = i * max_rows + 1
      end_row = ifelse((i+1) * max_rows < n_rows, (i+1)*max_rows, n_rows)
      wlog(paste0("Uploading to SCHEMA '",schema,"': TABLE '",name,"'",' rows ', start_row,' to ', end_row))
      DBI::dbWriteTable(
        conn = con,
        value = df[start_row:end_row,],
        name = name,
        temporary = FALSE,
        append = T
      )
    }
    names(df) %>% walk(function(col) {
      wlog(paste0('Creating index for "',col,'"'))
      DBI::dbExecute(con,paste0('create index "',name,'.',col,'_idx" on ',schema,'.',name,' ("',col,'")'))
    })
    #    copy_to(con, df, name, temporary = FALSE, indexes = names(df) %>% str_subset("^.{1,62}$"), overwrite = T)
  })
  if (disconnect) sql_dis(con)
  return(con)
}

#'\code{sql_get_tables} get list of data frames from vector of table names
#'@param table_names vector of table names (default: all tables)
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param disconnect disconnect con when finished?, default FALSE
#'@return list of data frames
#'@export
sql_get_tables = function(table_names, con, schema, disconnect=F) {
  if (!missing(schema)) DBI::dbExecute(con,paste0('SET search_path TO ', schema))
  if (missing(table_names)) table_names = dbListTables(con)
  ret = map(table_names, function(table_name) {
    DBI::dbGetQuery(con, paste("SELECT * FROM",table_name)) %>% as_tibble()
  }) %>% set_names(table_names) %>% as.list()
  if (disconnect) sql_dis(con)
  return(ret)
}

#'\code{sql_get_table} get a data frame from table name
#'@param table_name table name
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param disconnect disconnect con when finished?, default FALSE
#'@return data frame
#'@export
sql_get_table = function(table_name, con, schema, disconnect=F) {
  if (!missing(schema)) DBI::dbExecute(con,paste0('SET search_path TO "', schema,'"'))
  ret = DBI::dbGetQuery(con, paste0('SELECT * FROM "',table_name,'"')) %>% as_tibble()
  if (disconnect) sql_dis(con)
  return(ret)
}

#'\code{sql_to_xlsx} get list of data frames from vector of table names and write them to excel file
#'@param table_names vector of table names
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param xlsx url to xlsx file
#'@param disconnect disconnect con when finished?, default FALSE
#'@export
sql_to_xlsx = function(table_names, con, schema, xlsx, disconnect=F, ...) {
  dfs = sql_get_tables(table_names = table_names, schema = schema, con = con)
  openxlsx::write.xlsx(x = dfs, file = xlsx, asTable = T, ...)
}

#'\code{xlsx_to_sql} write list of data frames to excel file
#'@param xlsx url to xlsx file
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param schema schema name
#'@param disconnect disconnect con when finished?, default FALSE
#'@export
xlsx_to_sql = function(xlsx, con, schema, disconnect=F, ...) {
  xlsx_dfs = read_excel_to_list(xlsx)
  sql_create_tables(dfs = xlsx_dfs, schema = schema, con = con)
  if (disconnect) sql_dis(con)
}

#'\code{sql_log} write log entry
#'@param trigger event, e.g. "podest_make()"
#'@param event event, e.g. "write"
#'@param object object of the event, e.g. "table"
#'@param info additional info
#'@param con dbConnect connection, e.g. created by sql_con(...)
#'@param disconnect disconnect con when finished?, default FALSE
#'@export
sql_log = function(trigger = "R script", event = "", object="", info="", con, disconnect=F) {
  DBI::dbExecute(con, "SET search_path TO podest")
  DBI::dbAppendTable(con, name="log", value = tibble(trigger = trigger, event = event, object = object, info = info))
  if (disconnect) sql_dis(con)
}
