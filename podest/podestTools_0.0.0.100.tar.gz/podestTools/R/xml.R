#'\code{xml_text_escape} escape special characters in text ("<", ">") for embedding in XML
#'@param text text to search for characters to transform
#'@return character string
#'@export
xml_text_escape = function(text) {
  search_replace = list(
    '&' = '&amp;',
    '<' = '&lt;',
    '>' = '&gt;',
    '\"' = '&quot;',
    '\'' = '&apos;'
  )
  return(stringi::stri_replace_all_fixed(text,names(search_replace),unlist(search_replace, use.names=FALSE), vectorize_all = F))
}

#'\code{xml_crop} cropping XML code to a maximum length, maintaining a valid XML node sequence
#'@param xml XML string
#'@param max_length maxmimum length of XML string
#'@return character string
#'@export
xml_crop = function(xml, max_length) {
  map_chr(xml, function(c_xml) {
    c_xml = str_replace_all(str_replace_all(c_xml,'&','&amp;'),'&amp;([A-Za-z0-9]+;|#[x0-9]+;)','&\\1')
    if (is.na(c_xml) | str_length(c_xml) < max_length) c_xml
    else {
      simple_sub = str_sub(c_xml,1,max_length)
      if (!str_detect(simple_sub,'<')) simple_sub
      else xml2::read_xml(paste0("<el>",c_xml,"</el>")) %>%
        xml_contents() %>%
        as.character() %>%
        enframe() %>%
        mutate(value=str_replace_all(value,'\\\\\\"',"'"), length=str_length(xml_text_escape(value))) %>%
        mutate(
          cs=cumsum(length),
          last_cs = coalesce(lag(cs),0),
          new = case_when(
            cs <= max_length ~ value,
            last_cs <= max_length & cs > max_length & !str_starts(value,'<') ~ str_sub(value,1,max_length - last_cs),
            T ~ ''
          )) %>%
        filter(last_cs <= max_length) %>%
        pull(new) %>%
        paste0(collapse = "")
    } %>% str_remove('&[^;]*$')
  })
}
