#' #'\code{init_TMO} set proxy environment and return TMO variables (paths, ip address)
#' #'@return list of TMO variables
#' #'@export
#' init_TMO = function() {
#'   isOdcfWorker = startsWith(Sys.info()["nodename"],'odcf')
#'   isLinux = (Sys.info()[['sysname']]=="Linux")
#'   userprofile = ifelse(
#'     isLinux,
#'     Sys.getenv("HOME"),
#'     normalizePath(Sys.getenv("USERPROFILE"),winslash = '/'))
#'   TMO_data_dir = if (length(Sys.glob(paths = paste0(userprofile,'/seadrive_root/*/*/TMO_data')))>0) { Sys.glob(paths = paste0(userprofile,'/seadrive_root/*/*/TMO_data'))
#'   } else if (dir.exists(paste0(userprofile,'/nextcloud/OE0246 Projects/TMO/TMO_data')))  { paste0(userprofile,'/nextcloud/OE0246 Projects/TMO/TMO_data')
#'   } else paste0(userprofile , '/nextcloud/TMO_data')
#'   TMO_temp = list(
#'     TMO_data_dir = TMO_data_dir,
#'     TMO_data_dev_dir = paste0(TMO_data_dir,'_dev'),
#'     TMO_download_dir = paste0(TMO_data_dir,'_dev/Downloads'),
#'     MTB_dir = paste0(TMO_data_dir,'/../MTB'),
#'     ip = if (isLinux) {NA} else {system('ipconfig', intern = T) %>% str_subset("IPv4") %>% str_subset("\\.1$", negate = T) %>% str_extract('\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}') %>% first()},
#'     get_ip = function() {system('ipconfig', intern = T) %>% str_subset("IPv4") %>% str_subset("\\.1$", negate = T) %>% str_extract('\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}') %>% first()},
#'     dkfz_login = NA,
#'     dkfz_password = NA,
#'     onkostar1_login = NA,
#'     onkostar1_password = NA,
#'     userprofile = userprofile
#'   )
#'   if (exists('TMO')) TMO_temp = modifyList(TMO_temp,TMO)
#'   return(TMO_temp)
#' }
