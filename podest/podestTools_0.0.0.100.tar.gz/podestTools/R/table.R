
#' Replace missing values with NA
#'
#' Checks all field in \code{df} for "", ".", and "-" and replaces them with NA
#' Remark: There exist function doing this job and allowing for selection of values
#' that one wants to convert to NA (\link[naniar]{replace_with_na } and \link[sjlabelled]{set_na }).
#' However, these functions seem to be quite slow and thus this non-generic function has been developed.
#'
#' @param df a data frame or tibble
#'
#' @export
#'
#' @examples df <- tibble::tribble(~x, ~y,~z,
#' 1,   ".",   -100,
#' 3,   "-", -99,
#' NA,  NA,    -98,
#' -99, "",   -101,
#' -98, "",   -1)
#'
#' replace_vaules_with_na(df)
replace_values_with_na <- function(df){
  mutate(df, across(.cols = everything(),~na_if(.x, ""))) %>%
    mutate(across(.cols = everything(),~na_if(.x, "-"))) %>%
    mutate(across(.cols = everything(),~na_if(.x, ".")))
}




#'Transform table into podest standard format
#'
#'\code{table_normalize} add table suffix to columns (if missing), sort columns by id,
#' name and suffix, and convert to tibble.
#' The table name is given by the (1) tablename parameter,
#' (2) the suffix of the 1st column (if it matches 'id.NAME') or the variable name.
#'
#'
#'@param table df table (i.e. data.frame)
#'@param name table name
#'@param check_missing_values check for missing values (any "", ".", or "-")
#'and replace by NA. Default = \code{FALSE}.
#'
#'
#'@return tibble
#'@export
table_normalize = function(df, table_name=NA_character_, check_missing_values = FALSE) {
  table_name = coalesce(table_name, { col1name = colnames(df)[[1]]; if (str_detect(col1name,'^id\\.')) str_remove(col1name,'^id\\.') else NA_character_ }, deparse(substitute(df)))

  df <- df %>% as_tibble() %>%
    rename_at(vars(!matches('\\.')),function(colname) {
      pre = str_remove(colname,'__.+$')
      post = coalesce(str_extract(colname,'__[^_].*$'),'')
      paste0(pre,'.',table_name,post)
      }) %>%
    select(
      tibble(name = colnames(.)) %>%
        mutate(
          pos = row_number(),
          table = str_remove(name,'^.*\\.'),
          is_id = ifelse(str_detect(name,'^id\\.'),0,1),
          is_table_field = ifelse(str_detect(name,paste0('\\.',table_name)),0,1)
        ) %>%
        arrange(is_table_field, is_id, name) %>%
        .$pos)
  if (check_missing_values){
    df <- replace_vaules_with_na(df)
  }
  return(df)


}

#'Transform table into the new podest standard format
#'
#'\code{norm_cols} add table suffix to columns, sort columns by id,
#' name and suffix, and convert to tibble.
#' The table name is given by the (1) tablename parameter
#'
#'@param table df table (i.e. data.frame)
#'@param name table name
#'
#'
#'@return tibble
#'@export
norm_cols = function(df, table_name) {
  df <- df %>% as_tibble() %>%
    rename_at(vars(!matches('@')),function(colname) {
      # pre = str_remove(colname,'__.+$')
      # post = coalesce(str_extract(colname,'__[^_].*$'),'')
      # paste0(pre,'@',table_name,post)
      paste0(colname,'@',table_name)
    }) %>%
    select(
      tibble(name = colnames(.)) %>%
        mutate(
          pos = row_number(),
          table = str_remove(name,'^.*\\.'),
          is_id = ifelse(str_detect(name,'^id@'),0,1),
          is_table_field = ifelse(str_detect(name,paste0('\\.',table_name)),0,1)
        ) %>%
        arrange(is_table_field, is_id, name) %>%
        .$pos)
  return(df)
}
