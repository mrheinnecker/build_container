#'\code{file.copy_with_date} copy files keeping the date
#'@param from source file(s)
#'@param to target file(s)
#'@return nothing
#'@export
file.copy_with_date = function(from, to) {
  walk2(from, to, function(f,t) {
    wlog(paste0("Copying with date: ",f," to ",t))
    system2('cmd.exe', paste0('/c copy "',normalizePath(f, winslash = '\\'),'" "',t,'"'), stdout=F)
  })
}

#'\code{dir.copy} copy directory
#'@param from source dir(s)
#'@param to target dir(s)
#'@param delete Initially delete target dir if it exists? [T]
#'@return nothing
#'@export
dir.copy = function(from, to, delete=T) {
  walk2(from, to, function(f,t) {
    if ((delete==T) & dir.exists(t)) unlink(t, recursive = T, force = T)
    system2('cmd.exe', paste0('/c xcopy "',normalizePath(f, winslash = '\\'),'" "',t,'" /e /i /y'), stdout=F)
  })
}

#'\code{archive_file} archive file
#'@param file url of file(s) [vectorized]
#'@param archive_clean Clean the archive directory (removing old directories, keeping daily versions for last week, weekly versions for last month, monthly versions for last year, 3-months versions for years before)? [F] [vectorized]
#'@param archive_md5 Create md5 checksum file for latest archive [md5_latest.txt]? [T]
#'@return nothing
#'@export
archive_file = function(file, archive_clean=F, archive_md5=T) {
  walk(file, function(f) {
    f_name = basename(f)
    f_dir = dirname(f)
    archive_dir = paste0(f,'_archive')
    archive_file = paste0(archive_dir,'/',Sys.Date(),'_',f_name)
    if (!file.exists(archive_dir)) dir.create(archive_dir,recursive = T)
    file.copy(f, archive_file, copy.date = T, overwrite = T)
    if (archive_clean==T) archive_clean(archive_dir)
    if (archive_md5==T) archive_md5(file=file)
  })
}

#'\code{archive_dir} archive file
#'@param file url of file(s) [vectorized]
#'@param archive_clean Clean the archive directory (removing old directories, keeping daily versions for last week, weekly versions for last month, monthly versions for last year, 3-months versions for years before)? [F] [vectorized]
#'@param archive_md5 Create md5 checksums file for latest archive [md5_latest.txt]? [T]
#'@return nothing
#'@export
archive_dir = function(dir, archive_clean=F, archive_md5=T) {
  walk(dir, function(d) {
    d_name = basename(d)
    d_dir = dirname(d)
    archive_dir = paste0(d_dir,'/',d_name,'_archive')
    if (!file.exists(archive_dir)) dir.create(archive_dir,recursive = T)
    unlink(paste0(archive_dir,'/',d_name), recursive = T, force = T)
    unlink(paste0(archive_dir,'/',Sys.Date()), recursive = T, force = T)
    file.copy(d, archive_dir, copy.date = T, overwrite = T, recursive = T)
    file.rename(from = paste0(archive_dir,'/',d_name), to = paste0(archive_dir,'/',Sys.Date()))
    if (archive_clean==T) archive_clean(archive_dir)
    if (archive_md5==T) archive_md5(dir=dir)
  })
}

archive_md5 = function(file, dir) {
  files = ifelse(missing(file),list.files(dir,full.names = T),file)
  archive_dir = paste0(ifelse(missing(file),dir,file),'_archive')
  md5.txt_url = paste0(archive_dir,'/md5_latest.txt')
  md5_old = if (file.exists(md5.txt_url)) read_tsv(md5.txt_url, col_types = cols()) else tibble(file=NA, md5='')
  md5_new = files %>% enframe(name = NULL, value = 'url') %>%
    transmute(
      md5= map_chr(url,function(u) { digest::digest(object = u, algo = "md5", file = T)}),
      file = basename(url)
    )
  left_join(md5_new,md5_old, by='file') %>%
    transmute(
      md5 = md5.x,
      file,
      changed = (is.na(md5.y) | md5.x!=md5.y)
    ) %>%
    write_tsv(md5.txt_url)
}

#'\code{archive_clean} clean archive directory (removing old directories, keeping daily versions for last week, weekly versions for last month, monthly versions for last year, 3-months versions for years before)
#'@param dir url of archive dir(s) [vectorized]
#'@return nothing
#'@export
archive_clean = function(dir) {
  walk(dir, function(d) {
#    unlink(Sys.glob(paste0(d,'/','*_archive_cleaned.txt')))
    filelist = list.files(path = d, include.dirs = T, full.names = T) %>%
      enframe(value = 'file') %>%
      mutate(name=str_remove_all(file,'.+/')) %>%
      filter(str_detect(name,'^\\d{4}\\-\\d{2}\\-\\d{2}')) %>%
      filter(!str_detect(name,'keep(\\.[^\\.]+)?$')) %>%
      mutate(
        date=str_replace(name,'^((\\d{4})\\-(\\d{2})\\-(\\d{2})).*$','\\1'),
        weeks_passed=round(difftime(Sys.Date(), date, units = c("weeks"))),
        month=str_replace(name,'^((\\d{4})\\-(\\d{2})\\-(\\d{2})).*$','\\3'),
        quarter = ceiling(as.integer(month) / 3),
        year=str_replace(name,'^((\\d{4})\\-(\\d{2})\\-(\\d{2})).*$','\\2'),
        days_passed = round(difftime(Sys.Date(), date, units = c("days"))),
        weeks_passed = round(difftime(Sys.Date(), date, units = c("weeks"))),
      ) %>%
      group_by(year, month, weeks_passed) %>% mutate(first_in_week = (row_number()==1)) %>%
      group_by(year, month) %>% mutate(first_in_month = (row_number()==1)) %>%
      group_by(year, quarter) %>% mutate(first_in_quarter = (row_number()==1)) %>%
      mutate(keep = case_when(
          days_passed < 7 ~ T,
          ((weeks_passed < 5) & first_in_week) ~ T,
          ((Sys.Date() - as.Date(date) < 365) & first_in_month) ~ T,
          T ~ first_in_quarter
      )) %>%
      filter(keep==F) %>%
      {unlink(.$file, recursive = T)}
#    file.create(paste0(d,'/',Sys.Date(),'_archive_cleaned.txt'))
  })
}
