#'\code{webdav_upload} upload files via webdav
#'@param file file(s) to upload, e.g. 'c:/upload/image.gif' [vectorized]
#'@param dav_dir webdav dir(s) to upload to, e.g. 'https://www.myserver.com/images'  [vectorized]
#'@param login login for webdav server
#'@param password password for webdav server
#'@export
webdav_upload = function(file, dav_file, login=NA, password=NA) {
  dav_file = str_replace_all(dav_file," ","%20")
  if (is.na(login)) login <- readline(prompt=paste0("Enter login for webdav access [",str_replace(dav,'^(.+?//)?(.+?)(/.*)?$','\\2'),"]: "))
  if (is.na(password)) password <- readline(prompt=paste0("Enter password for webdav access [",str_replace(dav,'^(.+?//)?(.+?)(/.*)?$','\\2'),"]: "))
  walk2(file, dav_file, function(f, d) {
    PUT(d, authenticate(user = login, password = password), body = upload_file(f))
  })
}
