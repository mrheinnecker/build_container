# readr extensions
# initiated 2019-06-26
# authors: Simon Kreutzfeldt

#'\code{read_excel_to_list} read all xls sheets as tables in a list (using readxl:read_excel)
#'@param xlsFile file url
#'@return list with tables from xls file
#'@export
read_excel_to_list = function(xlsFile, ...) {
  xlsFile = enc2native(xlsFile)
  sheet_names = readxl::excel_sheets(xlsFile)
  sheet_list = as.list(rep(NA, length(sheet_names)))
  names(sheet_list) = sheet_names
  for (sn in sheet_names) {
    print(paste('Reading',sn,' ...'))
    sheet_list[[sn]] = readxl::read_excel(xlsFile, sheet=sn,  ..., .name_repair = "unique") %>% as_tibble()
  }
  return(sheet_list)
}
