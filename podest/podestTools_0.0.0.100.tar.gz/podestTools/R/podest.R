#'\code{podest} get table from PODEST database
#'@param table table name
#'@param schema Schema name. If no schema is given, we will search for the first table in PODEST DB fitting the table name across all schemas.
#'@param con connection.
#'@param asTibble return as tibble or a dynamic dbplyr table (default: false)
#'@param fullColNames use full column names (default: false)
#'@return dbplyr table
#'@export
podest = function(table, schema, con, asTibble=F, fullColNames = F) {
  if (missing(con)) {
    if (exists("conPodest")) if (class(conPodest)!="PqConnection") conPodest <<- sql_con()
    if (!exists("conPodest")) conPodest <<- sql_con()
    con = conPodest
  }
  if (!missing(schema)) if (typeof(substitute(schema))=='symbol') schema = deparse(substitute(schema))
  if (!missing(table)) if (typeof(substitute(table))=='symbol') table = deparse(substitute(table))
  if (missing(schema)) {
    fittingTablesTbl = tbl(con,dbplyr::in_schema(schema = 'information_schema', table = 'tables')) %>%
      filter(str_detect(table_name,table)) %>% collect() %>% arrange(table_name!=table)
    fittingTables = pull(fittingTablesTbl,'table_name')
    fittingSchemas = pull(fittingTablesTbl,'table_schema')
    if (length(fittingTables) > 1) {
      wlog(paste0("Warning: There are multiple tables in PODEST fitting '^.*",table,".*$' in the following schemas:"))
      wlog(paste0(fittingSchemas, '.',fittingTables))
    }
    if (length(fittingTables) == 0) wlog(type = "error", text = paste0("Warning: There is no table in PODEST fitting '^.*",table,".*$'"))
    wlog('----------------------------------')
    wlog(paste0("Using now table ",fittingSchemas[[1]], '.',fittingTables[[1]]),":")
    t_link = dbplyr::in_schema(schema = fittingSchemas[[1]], table = fittingTables[[1]])
  } else {
    t_link = dbplyr::in_schema(schema = schema, table = table)
  }
  ret = tbl(con, t_link)
  if (asTibble) ret = as_tibble(ret)
  if (fullColNames) ret = ret %>% rename_with(~paste0(.x,'_',table), -matches('@|[A-Za-z0-9]_[A-Za-z0-9]'))
  return(ret)
}

#'\code{podest_make} run make on all podest libraries, updating RData and xlsx exports wherever files are outdated
#'@export
podest_make <- function() {
  podestDiagnosis::make_podestDiagnosis()
  podestMaster::make_podestMaster()
  podestTherapies::make_podestTherapies()
#  podestBioitems::make_export_podestBioitems()
  podestClinicalTrials::make_podestClinicalTrials()
  podestDiagnostics::make_podestDiagnostics()
}

#'\code{podest_export} exports tables in package_data to TMO_data/podest_data
#'@param package name of podest package
#'@param package_data list of data frames of podest package
#'@param single_file Put all tables in a single file (otherwise one file per table)? [F]
#'@param archive Create archive entry, too? [T]
#'@param archive_clean Clean archive? [T]
#'@param archive_md5 Create md5 checksum file for latest archive [latest_archive_md5.txt] and changed info for latest archive [latest_archive_changed.txt]? [F]
#'@export
podest_export <- function(package, package_data, single_file=F, archive=T, archive_clean=T, archive_md5=F) {
  #  package = as.character(substitute(package))
  #library(package, character.only = T)
  #if (missing(package_data)) package_data = eval(parse(text=paste0('build_',package,'()')))
  if (single_file==T) {
    RData_file = paste0(TMO$TMO_data_dir,'/podest_data/',package,'/',package,'.RData')
    xlsx_file =  paste0(TMO$TMO_data_dir,'/podest_data/',package,'/',package,'.xlsx')
    if (dir.exists(dirname(RData_file))==F) dir.create(dirname(RData_file))
    if (dir.exists(dirname(xlsx_file))==F) dir.create(dirname(xlsx_file))
    wlog(paste('Writing',RData_file))
    save(list = as.character(substitute(package_data)),file = RData_file, envir = parent.frame())
    wlog(paste('Writing',xlsx_file))
    openxlsx::write.xlsx(package_data, file=xlsx_file, zoom=80, asTable = T, firstRow=T, colWidths = "auto")
    if (archive==T) {
      archive_file(RData_file, archive_clean = archive_clean, archive_md5=archive_md5)
      archive_file(xlsx_file,  archive_clean = archive_clean, archive_md5=archive_md5)
    }
  } else {
    RData_dir = paste0(TMO$TMO_data_dir,'/podest_data/',package,'/RData')
    xlsx_dir =  paste0(TMO$TMO_data_dir,'/podest_data/',package,'/xlsx')
    if (dir.exists(RData_dir)==F) dir.create(RData_dir)
    if (dir.exists(xlsx_dir)==F) dir.create(xlsx_dir)
    walk2(names(package_data),package_data, function(tabGroupName,tabGroup) {
      RData_url = paste0(RData_dir,'/',tabGroupName,'.RData')
      xlsx_url =  paste0(xlsx_dir, '/',tabGroupName,'.xlsx')
      assign(tabGroupName,tabGroup, envir = .GlobalEnv)
      wlog(paste('Writing',RData_url))
      eval(parse(text=paste0("save(",tabGroupName,", file=RData_url)")))
      wlog(paste('Writing',xlsx_url))
      eval(parse(text=paste0("openxlsx::write.xlsx(",tabGroupName," %>% set_names(str_sub(names(",tabGroupName,"),1,31)), file=xlsx_url, zoom=80,asTable = T,firstRow=T,colWidths = 'auto', overwrite=T)")))
    })
    if (archive==T) {
      archive_dir(RData_dir, archive_clean = archive_clean, archive_md5=archive_md5)
      archive_dir(xlsx_dir,  archive_clean = archive_clean, archive_md5=archive_md5)
    }
  }
}

#'\code{podest_documentation_update} downloads current lucidchart csv and pdf version and updates (and archives) podest_documentation.xlsx
#'@export
podest_documentation_update = function() {
  suppressMessages(file.remove(list.files(path = TMO$TMO_download_dir, pattern = paste0('podest.*\\.csv'), full.names = T)))
  suppressMessages(file.remove(list.files(path = TMO$TMO_download_dir, pattern = paste0('podest.*\\.pdf'), full.names = T)))
  rs_firefox_start('https://app.lucidchart.com/lucidchart/c6d59022-9a07-493b-a47b-7aef6a0603b7/edit?page=18_45#?folder_id=home&browser=icon') %>%
    rs_clickElement(".//div[@class='login-with-password setting']", times=20) %>%
    rs_typeInElement(".//input[@name='init-username'][1]",list("")) %>%
    rs_typeInElement(".//input[@name='init-username'][1]",list("","simon.kreutzfeldt@med.uni-heidelberg.de", key= "tab", "lC7iNFgsKi", key = "enter")) %>%
    rs_waitForElement("//span[@class='text' and normalize-space(.)='ENTWURF']") %>%
    rs_clickElement("//span[@id='menubar-item-file']", times=20) %>%
    rs_clickElement("//span[@class='label' and normalize-space(.)='Exportieren']", times=20) %>%
    rs_clickElement("//span[@class='label' and normalize-space(.)='CSV von Formdaten']", times=20) %>%
    p_sleep(8) %>%
    rs_clickElement("//span[@id='menubar-item-file']", times=20) %>%
    rs_clickElement("//span[@class='label' and normalize-space(.)='Exportieren']", times=20) %>%
    rs_clickElement("//span[@class='label' and normalize-space(.)='PDF']", times=20) %>%
    rs_clickElement("//lucid-button[@ng-reflect-label='Download']", times=20) %>%
    p_sleep(10) %>%
    rs_quit()

  podest_ERM.pdf_file_new = paste0(TMO$TMO_data_dev_dir,'/Downloads/podest - ERM.pdf')
  podest_ERM.pdf_file = paste0(TMO$TMO_data_dir,'/podest_documentation/lucidchart/podest - ERM.pdf')
  if (!file.exists(podest_ERM.pdf_file_new)) {
    wlog('WARNING: podest - ERM.pdf was not downloaded!')
  } else {
    file.remove(podest_ERM.pdf_file)
    file.rename(podest_ERM.pdf_file_new,podest_ERM.pdf_file)
    archive_file(podest_ERM.pdf_file, archive_clean = T)
  }

  podest.csv_file_new = paste0(TMO$TMO_data_dev_dir,'/Downloads/podest.csv')
  podest.csv_file = paste0(TMO$TMO_data_dir,'/podest_documentation/lucidchart/podest.csv')
  if (!file.exists(podest.csv_file_new)) {
    wlog('WARNING: podest.csv was not downloaded! I will stop updating podest.csv')
  } else {
    file.remove(podest.csv_file)
    file.rename(podest.csv_file_new,podest.csv_file)
    archive_file(podest.csv_file, archive_clean = T)

    podest_documentation.xlsx_file = paste0(TMO$TMO_data_dir,'/podest_documentation/podest_documentation.xlsx')

    podest_csv = read_csv(podest.csv_file, col_types = cols())

    podest_documentation = podest_csv %>%
      filter(Name %in% c("Entität","Tabelle")) %>%
      select(group = Gruppe, name = Name, starts_with('Textbereich')) %>%
      group_by(group) %>%
      arrange(group, (name!="Tabelle"), `Textbereich 1`) %>%
      filter(first(name)=="Tabelle") %>%
      group_modify(function(pgroup, key) {
        podest_documentation_package = ungroup(pgroup) %>% filter(name=="Tabelle")
        podest_documentation_package_name = str_split(podest_documentation_package$`Textbereich 1`,pattern = '\u2028', n = 2, simplify = T)[1]
        podest_documentation_package_description = na_if(str_split(podest_documentation_package$`Textbereich 1`,pattern = '\u2028', n = 2, simplify = T)[2],"")
        podest_documentation_package_cols = podest_documentation_package %>%
          select(starts_with('Textbereich'), -"Textbereich 1") %>%
          as.character() %>% na_if("NA") %>%
          .[1:(3 * (length(.) %/% 3))] %>%
          matrix(ncol=3, byrow=T) %>% as_tibble() %>%
          setNames(c('row_type','col1','col2')) %>%
          transmute(package = podest_documentation_package_name, col1, col2, row_path=paste0(podest_documentation_package_name,'.',row_type), row_type=paste0('p_',row_type)) %>%
          filter(!is.na(col1))
        podest_documentation_tables = pgroup %>% filter(name=="Entität") %>%
          rowwise() %>%
          group_map(function(trow, key) {
            podest_documentation_table_name = str_split(trow$`Textbereich 1`,pattern = '\u2028', n = 2, simplify = T)[1]
            podest_documentation_table_description = str_split(trow$`Textbereich 1`,'\u2028', n = 2, simplify = T)[2]
            podest_documentation_table_rows = trow %>%
              select(starts_with('Textbereich'), -"Textbereich 1") %>%
              as.character() %>% na_if("NA") %>%
              .[1:(3 * (length(.) %/% 3))] %>%
              matrix(ncol=3, byrow=T) %>%
              as_tibble() %>%
              setNames(c('col1','col2','col3')) %>%
              transmute(package = podest_documentation_package_name, col1, col2, col3, row_type="t_field", row_path=paste0(podest_documentation_package_name,'.table.',podest_documentation_table_name,'.','field')) %>%
              filter(!is.na(col1))
            bind_rows(
              tibble(package = podest_documentation_package_name, col1 = podest_documentation_table_name, col2=NA, col3=NA, row_type="t_name", row_path=paste0(podest_documentation_package_name,'.table.',podest_documentation_table_name,'.name')),
              if (podest_documentation_table_description!='') {tibble(package = podest_documentation_package_name, col1 = podest_documentation_table_description, row_type="t_desc", row_path=paste0(podest_documentation_package_name,'.table.',podest_documentation_table_name,'.','description'))},
              podest_documentation_table_rows
            )
          })
        bind_rows(
          tibble(package = podest_documentation_package_name, col1 = podest_documentation_package_name, col2 = NA, col3 = NA, row_type = "p_name", row_path=paste0(podest_documentation_package_name,'.name')),
          tibble(package = podest_documentation_package_name, col1 = podest_documentation_package_description, col2 = NA, col3 = NA, row_type = "p_desc", row_path=paste0(podest_documentation_package_name,'.description')),
          podest_documentation_package_cols,
          podest_documentation_tables
        )
      })

    style_p_name = createStyle(fontSize = 36, fontColour='#ffffff', bgFill = "#0070C0", textDecoration = c('bold'))
    style_p_desc = createStyle(fontColour = "#444444", bgFill = "#AACC31", textDecoration = c('italic'))
    style_p_source_col1 = createStyle(fontColour = "#0070C0", textDecoration = c('bold'))
    style_p_source_col2 = createStyle(fontColour = "#888888")
    style_t_name = createStyle(fontSize = 24, fontColour = "#0070C0", bgFill = "#AFD3FF", textDecoration = c('bold'))
    style_t_desc = createStyle(fontColour = "#444444", bgFill = "#AACC31", textDecoration = c('italic'))
    style_t_field_col1 = createStyle(fontColour = "#0070C0", textDecoration = c('bold'))
    style_t_field_col2 = createStyle(fontColour = "#888888")
    style_t_field_col3 = createStyle(fontColour = "#839424")
    style_hidden = createStyle(fontColour = "#BFBFBF")

    wb = openxlsx::createWorkbook()

    add_Sheet = function (wb, name, dataTable, tabColour) {
      openxlsx::addWorksheet(wb, name, zoom = 85, tabColour = tabColour)
      openxlsx::writeData(wb, name, dataTable, withFilter = FALSE, colNames = F)

      openxlsx::addStyle(wb, name, style = style_p_name,  rows = 1, cols = 1)
      openxlsx::addStyle(wb, name, style = style_t_field_col3,  rows = 1:nrow(dataTable), cols = 3, gridExpand = T)
      openxlsx::addStyle(wb, name, style = style_hidden, rows = 1:nrow(dataTable), cols = 4:5, gridExpand = T)

      openxlsx::conditionalFormatting(wb,name, cols=1:3, rows=1, rule='$D1="p_name"', style = style_p_name)
      openxlsx::conditionalFormatting(wb,name, cols=1:3, rows=1:nrow(dataTable), rule='$D1="p_desc"', style = style_p_desc)
      openxlsx::conditionalFormatting(wb,name, cols=1, rows=1:nrow(dataTable), rule='$D1="p_source"', style = style_p_source_col1)
      openxlsx::conditionalFormatting(wb,name, cols=2, rows=1:nrow(dataTable), rule='$D1="p_source"', style = style_p_source_col2)
      openxlsx::conditionalFormatting(wb,name, cols=1:3, rows=1:nrow(dataTable), rule='$D1="t_name"', style = style_t_name)
      openxlsx::conditionalFormatting(wb,name, cols=1:3, rows=1:nrow(dataTable), rule='$D1="t_desc"', style = style_t_desc)
      openxlsx::conditionalFormatting(wb,name, cols=1, rows=1:nrow(dataTable), rule='$D1="t_field"', style = style_t_field_col1)
      openxlsx::conditionalFormatting(wb,name, cols=2, rows=1:nrow(dataTable), rule='$D1="t_field"', style = style_t_field_col2)
      openxlsx::conditionalFormatting(wb,name, cols=3, rows=1:nrow(dataTable), rule='$D1="t_field"', style = style_t_field_col3)
      setColWidths(wb, name, cols = 1:6, widths = c(40,40,150,10,50))
      setColWidths(wb, name, cols = 4:16384, hidden = rep(TRUE, length(4:16384)))
      head_row_numbers = dataTable %>% mutate(hrn = if_else(row_type=='t_name',row_number(),NA_integer_)) %>% pull(hrn) %>% {.[!is.na(.)]}
      setRowHeights(wb, name, rows = c(1,head_row_numbers), heights = c(50,rep(40,length(head_row_numbers))))
      freezePane(wb, name, firstRow = TRUE)
    }

    podest_documentation %>%
      group_by(package) %>%
      dplyr::group_walk(function(pkg,key) {
        pkg_wog = ungroup(pkg) %>% select(-group)
        add_Sheet(wb,name=as.character(key),dataTable=pkg_wog, tabColour = '#FFFF99')
      })

    openxlsx::saveWorkbook(wb, podest_documentation.xlsx_file, overwrite = TRUE)
    archive_file(podest_documentation.xlsx_file, archive_clean = T)
  }
}

#'\code{podcat_update} update existing podest catalog table with new source data
#'@param cat new catalog data
#'@param cat_file url of existing catalog file
#'@param by name of column that should be used for (left) joining
#'@return joined podest catalog table
#'@export
podcat_update = function (cat, cat_file, by) {
  cat_old = (if (file.exists(cat_file)) read_xlsx(cat_file) %>% select(!ends_with('_new')) else cat[0,] )
  cat_renamed = cat %>% rename_with(~paste0(.x,'_new'), !(by))

  # cat_matched = entries in cat which do possibly have a corresponding entry in cat, in this case overriding column values from the new table
  cat_matched =
    left_join(cat_renamed,cat_old, by=c(by)) %>%
    transmute(
      across(by),
      across(!any_of(by) & !ends_with('_new'), function(col) { coalesce(col,.[[paste0(cur_column(),'_new')]]) }),
      across(ends_with('_new'), function(col) { col }),
    )

  # cat_unmatched = entries in cat_odl which do not have a corresponding entry in cat
  cat_old_unmatched = anti_join(cat_old, cat, by=by)

  cat_integrated = bind_rows(cat_old_unmatched, cat_matched)
  return(cat_integrated)
}

#'\code{podcat_write_xlsx} write podest catalog to file
#'@param cat new catalog data
#'@param cat_file url of catalog file
#'@param tab name of tab in excel
#'@param colWidth width of columns
#'@param pass return cat file?
#'@export
podcat_write_xlsx = function(cat, cat_file, tab = "cat", colWidth=NA, pass=F) {
  colCount = length(cat)
  colWidth = coalesce(colWidth,rep(20,colCount))
  grayStyle = openxlsx::createStyle(fontColour = "#888888")
  wb = openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, tab, zoom = 85)
  openxlsx::writeDataTable(wb, tab, cat, tableStyle = "TableStyleMedium2", withFilter = FALSE)
  openxlsx::freezePane(wb, tab, firstRow = TRUE)
  openxlsx::setColWidths(wb, tab, cols = 1:colCount, widths = colWidth)
  openxlsx::setRowHeights(wb,tab, rows = 1:nrow(cat)+1, heights = 20)
  openxlsx::addStyle(wb, tab, grayStyle,  rows = 1:nrow(cat)+1, cols = 1+ceiling(colCount/2):colCount, gridExpand = TRUE)
  openxlsx::saveWorkbook(wb, cat_file, overwrite = TRUE)
  if (pass==T) return(cat)
}


#'\code{podest_dGeneExpression_get_q} get quantile for gene expression
#'@param symbol gene symbol
#'@param fpkm fpkm value
#'@param tpm tpm value
#'@export
podest_dGeneExpression_get_q = function(symbol, fpkm=0, tpm=0) {
  tpmP = tpm
  fpkmP = fpkm
    dplyr::tbl(sql_con(),dbplyr::in_schema('statistics', table = "dGeneExpression")) %>%
      filter(symbol_geneHgnc==symbol & tpm > tpmP & fpkm > fpkmP) %>%
      pull(q) %>% {c(. - 0.01, 1)[1]} %>%
      return()
}


