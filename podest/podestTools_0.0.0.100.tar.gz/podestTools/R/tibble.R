#'\code{list2tibble} convert a list of vectors (of possibly different length) to a tibble, adding NA for all missing vector values.
#'@param l list to convert
#'@return tibble with list entries (vectors) converted to columns
#'@export
list2tibble = function(l) {
  as_tibble(sapply(l,'[', seq(max(sapply(l, length)))))
}

#'\code{fix_date_cols} read and tranform date string or numeric values from Excel to real date values in a tibble
#'@param df data frame
#'@param cols vector of column names that should be converted to date
#'@return tibble with correct date columns
#'@export
fix_date_cols = function(df,cols) {
  as_tibble(mutate(df,
                   across(all_of(cols),
                          ~ if_else(str_detect(.x,'^[0-9][0-9][0-9][0-9][0-9]$'),lubridate::as_date(as.integer(.x), origin="1970-01-01"),lubridate::as_date(.x))
                   )))
}

#'\code{cleanCamel} rename columns in data frame according to camelCase rules, renaming the "." with "_" to seperate external tables.
#'@param df data frame
#'@param rm_suffix should I also remove a certain suffix from the table?
#'@return tibble with correct column names
#'@export
cleanCamel = function(df, rm_suffix="THIS_IS_THE_TABLE_SUFFIX") {
  df %>% rename_with(~str_remove(.x,rm_suffix)) %>%
    rename_with(~str_replace_all(.x,'_[a-z]',toupper)) %>%
    rename_with(~str_remove_all(.x,'\\_')) %>%
    rename_with(~str_replace_all(.x,'\\.','_'))
}

#'\code{camelCase} convert strings to camelCase
#'@param strings string to convert
#'@return strings in camelCase
#'@export
camelCase = function(strings) {
  strings %>% map_chr(function(s) {
    str_replace_all(s,'_[a-z]',toupper) %>%
    str_remove_all('\\_') %>%
    str_replace_all('\\.','_')
  })
}

