.onLoad <- function(libname, pkgname) {
  writeLines("Starting podestTools...")
  library(tidyverse)
  options(crayon.enabled=T)
  options(crayon.colors=256)
  if (Sys.info()[['sysname']]=='Windows') {
    pa = suppressWarnings(system('ping www-int2.inet.dkfz-heidelberg.de -n 1 -w 200', intern=T))
    if (length(grep("Empfangen = 1",pa, useBytes = T)) > 0) {
      Sys.setenv(http_proxy = 'http://www-int2.inet.dkfz-heidelberg.de:80')
      Sys.setenv(https_proxy ='http://www-int2.inet.dkfz-heidelberg.de:80')
    } else {
      Sys.setenv(http_proxy = '')
      Sys.setenv(https_proxy ='')
    }
  }
  #TMO <<- init_TMO()
  #writeLines('Info: For local modifications (like setting TMO credential vars) store a file podestTools_init.R in ther user root dir (e.g. c:\\users\\schmidt) or in the working dir.')
  writeLines('CHANGED Info(!): I do NOT load podestTools_init.R any more when loading podestTools. The TMO list should be defined e.g. in .RProfile.')
  # if (file.exists(paste0(TMO$userprofile,"/podestTools_init.R"))) {
  #   writeLines(paste0("Running ",TMO$userprofile,"/podestTools_init.R"))
  #   source(paste0(TMO$userprofile,"/podestTools_init.R"), local = F)
  # }
  # if (file.exists("podestTools_init.R")) {
  #   writeLines("Running podestTools_init.R")
  #   source("podestTools_init.R", local = F)
  # }
}
