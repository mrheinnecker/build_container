#'\code{make_func} 'make'-inspired function calling: run func if any target file is outdated (or any source file has new md5 - if source_md5_file is given)
#'@param source source file(s) vector
#'@param source_md5_file tracking file where md5 values of all sources are stored
#'@param target target file(s) vector
#'@param func function to run if any target file is outdated (or any source has new md5, if source_md5_file is given)
#'@param fallback_func fallback function to run if all target file are up-to-date
#'@param force enforce make process?
#'@export
make_func = function(source, target=NULL, func, fallback_func, source_md5_file=NA, force=FALSE) {
  source = c(str_subset(source,'\\*', negate = T), Sys.glob(str_subset(source,'\\*')))
  target = c(str_subset(target,'\\*', negate = T), Sys.glob(str_subset(target,'\\*')))
  if (!is.null(target)) {
    #target_files = file.info(if (length(Sys.glob(target))==0) target else Sys.glob(target)) %>% as_tibble(rownames = 'file') %>%
    target_files = file.info(target) %>% as_tibble(rownames = 'file') %>%
      transmute(file = str_remove(file,'^.+TMO_data/'), mtime)
    target_files %>% filter(is.na(mtime)) %>% { walk(.$file, function(f) {wlog(paste('make_func: Target file ',f,'is missing.'))})}
    target_file_oldest_mtime = target_files$mtime %>% sort() %>% first()
  }
  #source_files = file.info(if (length(Sys.glob(source))==0) source else Sys.glob(source)) %>% as_tibble(rownames = 'file') %>%
  source_files = file.info(source) %>% as_tibble(rownames = 'file') %>%
    transmute(md5 = if (is.na(source_md5_file)) NA else map_chr(file,function(u) { digest::digest(object = u, algo = "md5", file = T)}), file = str_remove(file,'^.+TMO_data/'), mtime) %>%
    left_join(
      if (is.na(source_md5_file)) tibble(file.old=NA, md5.old=NA)
      else if (!file.exists(source_md5_file)) tibble(file.old=.$file, md5.old='0')
      else read_tsv(source_md5_file, col_types = cols()) %>% rename_with(~paste0(.x,'.old')), by=c('file'='file.old')) %>%
    mutate(
      new_md5=(md5!=coalesce(md5.old,'0')),
      newer_than_target = if (is.null(target)) {F} else if (is.na(target_file_oldest_mtime)) {F} else (mtime > target_file_oldest_mtime)
    )
  source_files %>% filter(new_md5 | newer_than_target) %>% {if (nrow(.)>0)
    rowwise(.) %>%
      { wlog(paste('make_func: Source file ',.$file,case_when(
        .$new_md5 & .$newer_than_target ~ paste0('has new md5 checksum and date (',.$md5.old,' -> ',.$md5,')'),
        .$new_md5 ~ paste0('has new md5 checksum (',.$md5.old,' -> ',.$md5,')'),
        T ~ 'has new date'
      )))}}
  if (force==T | any(c(
    source_files$new_md5,
    (source_files$newer_than_target & (!file.exists(coalesce(source_md5_file,'')))),
    if (!is.null(target)) is.na(target_files$mtime)),
    na.rm = T)) {
    func()
    if (!is.na(source_md5_file)) write_tsv(select(source_files,file,md5,mtime), source_md5_file)
  } else {
    if (!missing(fallback_func)) fallback_func()
  }
}

