#'\code{repeat_function} Repeat a function call until it returns a specified value
#'@param fun function to call
#'@param target_value target value [T]
#'@param times maximum numer of iterations [3]
#'@param wait waiting time between iterations in miliseconds [1000]
#'@return boolean vector
#'@export
repeat_function = function(fun=NA, target_value=T, fun_else=NA, times=3, wait=1000) {
  a = F
  i = 0
  repeat {
    a = fun()
    i=i+1
    if (a==target_value) break
    if (i==times) {
      print('Error in function:')
      print(fun)
      stop(paste("Function in repeat_function call did not return target value within",times,"iterations: "))
    }
    Sys.sleep(wait / 1000)
    print(paste('Repeat cycle',i+1))
    if (is.function(fun_else)) fun_else()
  }
  return(a)
}

#'\code{p_sleep} sleep for x seconds (within pipe structure)
#'@param o pipe object
#'@param sec seconds to sleep
#'@param text text to show
#'@return pipe
#'@export
p_sleep = function(o, sec = 5, text = NA) {
  force(o)
  print(paste0(ifelse(is.na(text),"",paste0(text,': ')),"Sleeping for ",sec," seconds..."))
  Sys.sleep(sec)
  return(o)
}

#'\code{sleep} sleep for x seconds
#'@param sec seconds to sleep
#'@export
sleep = function(sec = 5) {
  print(paste("Sleeping for",sec,"seconds..."))
  Sys.sleep(sec)
}

#'\code{saveRDATA} save variable to RDATA object (and create directory if necessary)
#'@param file file name
#'@return ret
#'@export
saveRDATA = function(..., file) {
  dirpath = dirname(file)
  if (!dir.exists(dirpath)) dir.create(dirpath, recursive = T)
  return(save(..., file=file))
}

#'\code{wlog} writing messages to console and possibly to log file
#'@param text text to log
#'@param color color of the message (default: 'silver')
#'@param bg_color is color s background color? (default: FALSE)
#'@param type type of message: 'text', 'warning' or 'error' (default: 'text')
#'@param log also write to log file?
#'@param log_file specify log file. If NA, variable .wlog_file is used.
#'@return ret
#'@export
wlog = function(text, type="text", color="silver", bg_color=NULL, log=F, log_file=NA) {
  log_file = if (!is.na(log_file)) {log_file} else if (exists('.wlog_file')) {.wlog_file} else {log_file}
  if (type=="warning")    { entry =  paste(format(Sys.time(), "%Y-%m-%d-%a %X"), "WARNING: ", text); writeLines(crayon::yellow(entry)) }
  else if (type=="error") { entry = paste(format(Sys.time(), "%Y-%m-%d-%a %X"), "ERROR: ", text); writeLines(crayon::magenta(entry)); if (log==T) write(x = entry, file = log_file, append = T); stop_quietly() }
  #  else                    { entry = paste(format(Sys.time(), "%Y-%m-%d-%a %X"), text); writeLines(style(entry, as = color, bg = bg_color)) }
  else                    { entry = paste(format(Sys.time(), "%Y-%m-%d-%a %X"), text); writeLines(entry) }
  if (log==T & !is.na(log_file)) write(x = entry, file = log_file, append = T)
}

#'\code{cmd_check} executing a cmd command and search the response for a specific string
#'@param command command to execute after "cmd.exe /c"
#'@param search string to search for in response
#'@param rep repetions of execution until search might be successful
#'@param int_sec interval in seconds between repetitions
#'@return ret
#'@export
cmd_check = function(command, search, rep=60, int_sec=1) {
  ret=F;
  for (i in 1:rep) {
    if (system2('cmd.exe', paste('/c',command), stdout = T, stderr = T) %>% str_detect(search) %>% any()) {ret=T; break; }
    wlog(paste("Command: cmd.exe /c", command, '- interval ',int_sec,"sec, cycle",i), log = F)
    Sys.sleep(int_sec)
  }
  return(ret)
}

#'\code{stop_quietly} stop without generating an error message [as stop() does].
#'@export
stop_quietly <- function() {
  opt <- options(show.error.messages = FALSE)
  on.exit(options(opt))
  stop()
}

#'\code{runAsyncJob} run R code asynchronously (using Rscript)
#'@param code code to execute
#'@param server Who is writing the message? Usually the name of the computer.
#'@param writer Writer (i.e. a script name) who is creating the log entry in Seatable.
#'@param lockfile Lock file to remove after the async script has ended. Useful to keep the parent process running (use e.g. a 'Sys::sleep' loop!) until the async job has ended.
#'@param ... variables to save to RData object and load before starting async code
#'@export
runAsyncJob = function(code, server, writer, lockfile=tempfile('lockFile'), ...) {
  if (missing(code)) wlog("'code' argument is missing in runAsyncJob", type = 'error')
  if (missing(server)) wlog("'server' argument is missing in runAsyncJob", type = 'error')
  if (missing(writer)) wlog("'writer' argument is missing in runAsyncJob", type = 'error')

  # create lockfile which contains the code that we later run using sys::r_wait
  if (!dir.exists(dirname(lockfile))) dir.create(dirname(lockfile), recursive = T)
  file.create(lockfile)

  # if the code need environmental variables, we will load them
  tmpRDataFileUrl = tempfile('tmpRDataFileUrl')
  print(paste('Using folder ',dirname(tmpRDataFileUrl), 'to create temp files.'))
  if (!dir.exists(dirname(tmpRDataFileUrl))) dir.create(dirname(tmpRDataFileUrl), recursive = T)
  if (!missing(...)) {
    save(..., file = tmpRDataFileUrl)
    write_lines(x = paste0("load('",tmpRDataFileUrl,"');"), file = lockfile)
  }

  # write the code to lockfile
  write_lines(x = code, file = lockfile, append = T)

  # create the parent script file that starts the logfile and that will be run via sys::r_background
  tmpParentCodeFileUrl = tempfile('tmpParentCodeFileUrl_')
  tmpLogFileUrl = tempfile('tmpLogFileUrl_')
  tmpErrLogFileUrl = tempfile('tmpErrLogFileUrl_')
  write_lines(x = paste0("sys::r_wait(std_in='",lockfile,"', args = c('--no-save', '--silent'), std_out = '",tmpLogFileUrl,"', std_err = '",tmpErrLogFileUrl,"')"), file=tmpParentCodeFileUrl)
  write_lines(x = paste0("library(podestTools)"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("seatable_log_write(server = '",server,"', writer = '",writer,"', type=(if (any(str_detect(readLines('",tmpErrLogFileUrl,"'),'Execution halted'))) 'error' else 'ok'), stdout = paste(readLines('",tmpLogFileUrl,"'), collapse='\\n'), stderr = paste(readLines('",tmpErrLogFileUrl,"'), collapse='\\n'))"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("file.remove('",tmpLogFileUrl,"')"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("file.remove('",tmpErrLogFileUrl,"')"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("file.remove('",tmpRDataFileUrl,"')"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("file.remove('",lockfile,"')"), file=tmpParentCodeFileUrl, append = T)
  write_lines(x = paste0("unlink('",dirname(tmpParentCodeFileUrl),"', recursive=T)"), file=tmpParentCodeFileUrl, append = T)

  # and now start the parent script
  sys::r_background(std_out = F, std_err = F, args = c('--no-save', '--silent'), std_in = tmpParentCodeFileUrl)

  # finally, let's remove the parent script and the whole temp folder

}


#'\code{runJob} Run R scripts e.g. from cron jobs. Optionally you can log stdout to Seatable CONTROLLER/logs (default) and report success e.g. to healthecks.io
#'@param file file to execute
#'@param wd set working directory
#'@param logInSeatable Log the execution of the script in Seatable? (default: T)
#'@param successUrl If we should log a successful run to e.g. healthchecks.io, give the url here.
#'@return result
#'@export
runJob = function(file, wd, logInSeatable=T, successUrl) {

  # set working directory
  if (!missing(wd)) setwd(wd)

  # vars
  filename = basename(file)
  tempfileRoot = tempfile(tmpdir = '/tmp/runJob', pattern = paste0(filename,'_'))
  lockfile = paste0(tempfileRoot,'.lock')
  stdoutfile = paste0(tempfileRoot,'.stdout')
  errorfile = paste0(tempfileRoot,'.err')
  runhelperfile = paste0(tempfileRoot,'.R')

  # create fir if it does not exist
  if (!dir.exists(dirname(lockfile))) dir.create(dirname(lockfile), recursive = T)

  # run script
  file.create(lockfile)

  startTime = Sys.time()
  if (!missing(wd)) write_lines(file = runhelperfile, x = paste0("setwd('",wd,"')"))
  write_lines(file = runhelperfile, x = paste0("source('~/.Rprofile')"), append = T)
  write_lines(file = runhelperfile, x = paste0("source('",file,"')"), append = T)
  result = sys::r_wait(args = c("-q --no-save --no-restore"), std_in = runhelperfile, std_out = stdoutfile, std_err = errorfile)
  unlink(runhelperfile)
  endTime = Sys.time()

  runTime = format(as.POSIXct(as.numeric(endTime - startTime, units = "secs"), origin = "1970-01-01", tz = "UTC"), format = "%H:%M:%S")

  stdout = read_lines(stdoutfile) %>% paste0(collapse = '\n') %>% {paste0('```\n',.,'\n```')}
  stderr    = read_lines(errorfile) %>% paste0(collapse = '\n') %>% {paste0('```\n',.,'\n```')}

  # unlink files
  unlink(c(lockfile,stdoutfile,errorfile))

  # Log to healthchecks.io
  # ping healthchecks.io URL to confirm script has been run
  if (!missing(successUrl)) {
    if (result==0) httr::GET(successUrl) # insert url provided by healthchecks.io
  } else successUrl=""

  # write log to seatable
  if (logInSeatable==T) {
    podestTools::seatable_log_write(
      server = Sys.info()[['nodename']],
      writer = file,
      type=(if (result==1) 'error' else 'ok'),
      stdout = stdout,
      stderr = stderr,
      dateTime = startTime,
      runTime = runTime,
      successUrl = successUrl
    )
  }

  return(result)
}

