# row manipulation --------------------------------------------------------
#'\code{seatable_log_write} write message to seatable/tmo_data/CONTROLLER/log
#'@param server which server is generating the message?
#'@param writer Who is writing the message (i.e. script name)?
#'@param stdout command output (or other log entry)
#'@param stderr command errors
#'@param type type of log message (default: ok)
#'@param dateTime date and time of log message
#'@param runTime run time of the script
#'@param successUrl To which url has the success been reported (if at all, e.g. to healthchecks.io)?
#'@export

seatable_log_write = function (server='', writer='', stdout = '', stderr = '', type="ok", dateTime = Sys.time(), runTime='', successUrl='', url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, message) {
  # stay compatible with old function
  if(missing(server) & !missing(message)) {
    server=writer
    if (!missing(message)) writer=message
    wlog('Warning: you use the old arguments in seatable_log_write. It now uses the triplet (server/writer/stdout) instead of the previous (writer/message/stdout). However I will gently change your message to server.', type = 'warning')
  }
  seatable_insert_rows(
#    df = tibble(writer=writer, message=message, stdout=stdout, stderr=stderr, type=type, dateTime=dateTime, dateTimeExact=dateTime),
    df = tibble(
      server=server,
      writer=writer,
      stdout=stdout,
      stderr=stderr,
      type=type,
      dateTime=dateTime,
      dateTimeExact=dateTime,
      runTime=runTime,
      successUrl=successUrl
      ),
    group = "TMO_data", base = "CONTROLLER", table = "log", url = url, user = user, password = password
  )
  return(paste0("seatableLog: ",writer,' [',server,']'))
}



# row manipulation --------------------------------------------------------
#'\code{seatable_merge_rows} update rows in ST with df, possibly add extra rows in ST from df, possibly remove rows in ST which have no match in df
#'@param df data frame (with column "_id" containing the internal seatable id of the columns to update)
#'@param group description
#'@param base description
#'@param table description
#'@param by name of column to use for updates
#'@param url description
#'@param user description
#'@param password description
#'@param add add additional rows to Seatable from df [default: T]
#'@param remove remove rows from Seatable missing in df [default: F]
#'@export

seatable_merge_rows = function (df, group, base, table, by = "_id", url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, add=T, remove = F) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  # update rows
  seatable_update_rows(df = df, group = group, base = base, table = table, by = by, url = url, user = user, password = password)

  if (remove==T | add==T) {
    st = seatable_get_table(group=group, base = base, table = table, url = url, user = user, password = password)
  }

  # remove rows
  if (remove==T) {
    st_remove_ids = anti_join(st,df,by=by) %>% pull(`_id`)
    seatable_delete_rows(row_ids = st_remove_ids, group=group, base = base, table = table, url = url, user = user, password = password)
  }

  # add rows
  if (add==T) {
    st_add_rows = anti_join(df, st,by=by)
    seatable_insert_rows(df = st_add_rows, group=group, base = base, table = table, url = url, user = user, password = password)
  }
}

#'\code{seatable_insert_rows} insert rows into table
#'@param df data frame
#'@param group description
#'@param base description
#'@param table description
#'@param url description
#'@param user description
#'@param password description
#'@return boolean
#'@export

seatable_insert_rows = function (df, group, base, table, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  ret = 0
  df %>%
    group_by((row_number()-1) %/% 1000) %>% # we have to split the dataframe to at max 1.000 rows because of the seatable API limit
    group_walk(function(d, k) {
      sql_req =
        curl::new_handle() %>%
        curl::handle_setheaders(
          Authorization = paste("Token", base_df$access_token),
          `Content-Type` = "application/json"
        ) %>%
        curl::handle_setopt(
          CUSTOMREQUEST = "POST",
          URL = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-append-rows/'),
          FOLLOWLOCATION = 1L,
          POSTFIELDS = paste0('{"table_name": "',table,'", "rows": ',jsonlite::toJSON(d, auto_unbox = T),'}')
        ) %>%
        curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-append-rows/'))
      ret = ret + as.double(jsonlite::fromJSON(rawToChar(sql_req$content)))
    })
  return(ret)
}

#'\code{seatable_update_rows} update rows in table
#'@param df data frame (with column "_id" containing the internal seatable id of the columns to update)
#'@param group description
#'@param base description
#'@param table description
#'@param view description
#'@param by name of column to use for updates
#'@param url description
#'@param user description
#'@param password description
#'@return boolean
#'@export

seatable_update_rows = function (df, group, base, table, view = "Default View", by = "_id", url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  # if "by" is not "_id", then create a new df by matching "by" column with the original df to get the "_id" values
  if (by!="_id") {
    t = seatable_get_table(group = group, base = base, table = table, view = view, url = url, user=user, password = password) %>% {filter(.,!is.na(.[[by]]))}
    if (length(unique(t[[by]])) < length(t[[by]])) {
      wlog(paste0("Column ",by, "is not unique! I have to stop seatable_update_rows."), type = "error")
    } else {
      df = df %>% select(-any_of("_id")) %>% left_join(distinct(t,across(.cols = c(`_id`, by)))) %>%
        select('_id', everything()) %>%
        filter(!is.na(`_id`))
    }
  }

  # update rows with df, using `_id` as the unique key
  ret = 0
  df %>%
    group_by((row_number()-1) %/% 1000) %>% # we have to split the dataframe to at max 1.000 rows because of the seatable API limit
    group_walk(function(d, k) {
      sql_req =
        curl::new_handle() %>%
        curl::handle_setheaders(
          Authorization = paste("Token", base_df$access_token),
          `Content-Type` = "application/json"
        ) %>%
        curl::handle_setopt(
          CUSTOMREQUEST = "PUT",
          URL = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-update-rows/'),
          FOLLOWLOCATION = 1L,
          POSTFIELDS = paste0('{"table_name": "',table,'", "updates": ',
                              map2(d$`_id`,purrr::transpose(d[2:length(d)] ), function(ii,rr) {list("row_id"=ii, "row"=rr)}) %>%
                                jsonlite::toJSON(auto_unbox = T)
                              # map2(d$`_id`,purrr::transpose(d[2:length(d)] %>% mutate(across(.cols = everything(), as.character))), function(ii,rr) {list("row_id"=ii, "row"=rr)}) %>%
                              #   jsonlite::toJSON(auto_unbox = T)
                              ,'}')
        ) %>%
        curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-update-rows/'))
      ret = ret + as.double(jsonlite::fromJSON(rawToChar(sql_req$content)))
      wlog(paste("Updating table",table, "cycle",k))
    })
  return(ret)
}

#'\code{seatable_delete_rows} delete rows from table
#'@param row_ids internal row_ids [character vector]
#'@param group description
#'@param base description
#'@param table description
#'@param url description
#'@param user description
#'@param password description
#'@return boolean
#'@export

seatable_delete_rows = function (row_ids, group, base, table, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  ret = 0
  split(row_ids, ceiling(seq_along(row_ids)/10000)) %>% # we have to split the dataframe to at max 1.000 rows because of the seatable API limit
    walk(function(ri) {
      sql_req =
        curl::new_handle() %>%
        curl::handle_setheaders(
          Authorization = paste("Token", base_df$access_token),
          Accept = "application/json",
          `Content-Type` = "application/json"
        ) %>%
        curl::handle_setopt(
          CUSTOMREQUEST = "DELETE",
          URL = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-delete-rows/'),
          FOLLOWLOCATION = 1L,
          POSTFIELDS = paste0('{"table_name": "',table,'", "row_ids": ["',paste(ri, collapse = '","'),'"]}') #,DEFAULT_PROTOCOL = "https"
        ) %>%
        curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/batch-delete-rows/'))
      ret = ret + as.double(jsonlite::fromJSON(rawToChar(sql_req$content)))
    })
  return(ret)
}

#'\code{seatable_delete_rows_all} delete all rows from table
#'@param group description
#'@param base description
#'@param table description
#'@param view description
#'@param url description
#'@param user description
#'@param password description
#'@return boolean
#'@export

seatable_delete_rows_all = function (group, base, table, view = "Default View", url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  row_ids = seatable_get_table(group=group, base=base, table=table, view = view, url=url, user=user, password=password)[['_id']]
  ret = seatable_delete_rows(group=group, base=base, table=table, row_ids = row_ids, url=url, user=user, password=password)
  return(ret)
}

# table manipulation ------------------------------------------------------


#'\code{seatable_get_table} get table from seatable.tmo-heidelberg.de
#'@param group description
#'@param base description
#'@param table description
#'@param view description
#'@param url description
#'@param user description
#'@param password description
#'@param flatten_multi_choice change multi-choice vectors (or reference table vectors) to pipe-separated strings? [default:true]
#'@param add_table_suffix add .table_name to columns without a dot? [default:false]
#'@return data frame
#'@export

seatable_get_table = function (group, base, table, view = "Default View", url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, flatten_multi_choice=T, add_table_suffix=F) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  metadata <- httr2::request(
    base_url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/metadata/')
    ) %>%
    httr2::req_headers(Authorization = paste("Token", base_df$access_token)) %>%
    httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_string(encoding = "UTF-8") %>%
    jsonlite::fromJSON() %>%
    {.$metadata}

  tableId = metadata$tables %>% as_tibble() %>%
    filter(name==table) %>%
    pull(`_id`)

  sort_string=""

  # get view information
  # req =
  #   curl::new_handle() %>%
  #   curl::handle_setheaders(Authorization = paste("Token", base_df$access_token)) %>%
  #   curl::curl_fetch_memory(url = URLencode(paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/views/',view,'/?table_name=',table)))
  # resp = rawToChar(req$content)
  # Encoding(resp) = "UTF-8"
  #
  # view_sort_df = jsonlite::fromJSON(resp)[['sorts']] %>% as_tibble()

  # get view columns
  # --> we need these because the API call below does unexpectedly not consider the hiding of cols so we have to select them below
  req =
    curl::new_handle() %>%
    curl::handle_setheaders(Authorization = paste("Token", base_df$access_token)) %>%
    curl::curl_fetch_memory(url = URLencode(paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/columns/?view_name=',view,'&table_name=',table)))
  resp = rawToChar(req$content)
  Encoding(resp) = "UTF-8"

  view_columns = c(jsonlite::fromJSON(resp)[['columns']] %>% pull("name"),'_id','_ctime','_mtime')

  # req (cycle till end of table)
  start_row=0
  repeat {
    wlog(paste0('Reading from Seatable: ',base,'/',table,'/',view,' - starting from row ',as.character(start_row + 1)))
    df0 = httr2::request(str_replace_all(paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/rows/?table_name=',table,'&view_name=',view,'&convert_link_id=true&start=',start_row),' ','%20')) %>%
      httr2::req_headers(Authorization = paste("Token", base_df$access_token)) %>%
      httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_string(encoding = "UTF-8") %>%
      jsonlite::fromJSON() %>% {as_tibble(.$rows)}
    for (i in setdiff(view_columns, names(df0))) { df0[,i] = NA_character_ }

    if (nrow(df0)==0 & start_row == 0) {
      df0 = setNames(as.data.frame(matrix(ncol=length(view_columns), nrow=0, data = '')),view_columns) %>% as_tibble()
    } else if (nrow(df0)>0) {
      df0 = df0 %>%
        # select only columns visible in view
        select(all_of(view_columns),starts_with('_'))
    }

    if (start_row==0) {
      df = df0
    } else {
      df = bind_rows(df,df0)
    }
    if (nrow(df0) < 10000) { break }
    start_row = start_row + 10000
  }


  # if (nrow(sql_sort_df)>0) {
  #   col_info_req =
  #     curl::new_handle() %>%
  #     curl::handle_setheaders(Authorization = paste("Token", base_df$access_token)) %>%
  #     curl::curl_fetch_memory(url = URLencode(paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/columns/?view_name=',view,'&table_name=',table)))
  #   col_info_resp = rawToChar(col_info_req$content)
  #   Encoding(col_info_resp) = "UTF-8"
  #   col_info = jsonlite::fromJSON(col_info_resp)[['columns']] %>% as_tibble()
  #   sort_col_names = sql_sort_df %>% left_join(col_info %>% select(column_key = key, name)) %>% pull(name)
  # have to look into this later - currently sorting is NOT done!
  # if (sql_sort_df$sort_type=='down') {sql_df = sql_df %>% arrange(across(sort_col_names, desc))}
  # else {                              sql_df = sql_df %>% arrange(across(sort_col_names, desc))}
  # }

  # if (keep_reference_tables==F || flatten_multi_choice==T) {
  #   sql_df = sql_df %>%
  #     mutate(across(where(~is.list(.x) && is.data.frame(.x[[1]])), ~map(.x, .f = function(df) {df$display_value})))
  # }
  if (flatten_multi_choice==T) {
    df = df %>%
      mutate(across(where(~is.list(.x)), function (x) {
        map(x, function(xx) {
          if (typeof(xx)=='character') {paste0(str_replace_all(xx,' ?, ?','#'), collapse = '#')}
          else {paste(xx$display_value, collapse = '#')}
        }) %>% unlist() %>% na_if("")
      }))
  }


  df = df %>%
    mutate(across(where(is.character),~na_if(.x,""))) %>% # replace empty-string values with NA
    mutate(
      `_editUrl` = paste0(url,'workspace/',base_df$workspace_id,'/dtable/',base,'/?tid=',tableId,'&row-id=',`_id`)
    )

  if (add_table_suffix==T) df = df %>% rename_with(function(col) {ifelse(str_detect(col,'[.]'),col,paste0(col,'.',table))})
  return(df)
}

#'\code{seatable_sql} use SQL on seatable.tmo-heidelberg.de
#'@param group description
#'@param base description
#'@param sql description
#'@param url description
#'@param user description
#'@param password description
#'@return data frame
#'@export

seatable_sql = function (group, base, sql, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, flatten_multi_choice=T) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  wlog(paste0('Running SQL on Seatable: ',group,'/',base))
  df = httr2::request(paste0(url,'dtable-db/api/v1/query/',base_df$dtable_uuid,'/')) %>%
    httr2::req_headers(Authorization = paste("Token", base_df$access_token)) %>%
    httr2::req_headers("Content-Type" = "application/json") %>%
    httr2::req_body_json(data = list(
      sql = sql,
      convert_keys = TRUE
    )
    ) %>% httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_string(encoding = "UTF-8") %>%
    jsonlite::fromJSON() %>% {as_tibble(.$results) }
  return(df)
}


#'\code{seatable_upload_df} upload data frame as table in seatable.tmo-heidelberg.de
#'@param df the data frame to upload
#'@param group description
#'@param base description
#'@param table description
#'@param url description
#'@param user description
#'@param password description
#'@param mode How should I treat existing tables? [default: upload, upload/overwrite/append]
#'@return success
#'@export

seatable_upload_df = function (df, group, base, table, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, mode = "upload") {
  csv_file = tempfile(pattern = "", fileext = ".csv")
  write_csv(x = df, file = csv_file, na='')
  seatable_upload_csv(group=group, base = base, table = table, csv_file = csv_file, mode = mode)
  file.remove(csv_file)
}

#'\code{seatable_upload_csv} upload csv as table in seatable.tmo-heidelberg.de
#'@param group description
#'@param base description
#'@param table description
#'@param url description
#'@param user description
#'@param password description
#'@param csv_file the csv file to upload
#'@param mode How should I treat existing tables? [default: upload, upload/overwrite/append]
#'@return data frame
#'@export

seatable_upload_csv = function (group, base, table, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password, csv_file, mode = "upload") {
  lines = readLines(csv_file)
  line0 = lines[1]
  lines_rest = lines[2:length(lines)]
  cycles = ceiling(length(lines_rest) / 10000)
  if (mode=='overwrite') {seatable_remove_table(group=group, base=base, table=table, url=url, user=user, password=password); mode = "upload"}
  for (i in 1:cycles) {
    block_lines = c(line0,lines_rest[(1 + (i-1)*10000):(i *10000)])
    csv_block_file = tempfile(pattern = "", fileext = ".csv")
    write_lines(block_lines,csv_block_file)
    if (i>1) mode = 'append'
    seatable_upload_csv_10000(csv_file=csv_block_file, group=group, base=base, table=table, url=url, user=user, password=password, mode=mode)
    file.remove(csv_block_file)
  }
}

#'\code{seatable_remove_table} remove table from seatable.tmo-heidelberg.de
#'@param group description
#'@param base description
#'@param table description
#'@param url description
#'@param user description
#'@param password description
#'@return boolean
#'@export

seatable_remove_table = function (group, base, table, url = "https://seatable.tmo-heidelberg.de/", user = TMO$dkfz_login, password = TMO$dkfz_password) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  sql_req =
    curl::new_handle() %>%
    curl::handle_setheaders(
      Authorization = paste("Token", base_df$access_token),
      `Content-Type` = "application/json"
    ) %>%
    curl::handle_setopt(
      CUSTOMREQUEST = "DELETE",
      URL = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/tables/'),
      FOLLOWLOCATION = 1L,
      POSTFIELDS = paste0('{"table_name": "',table,'"}')
    ) %>%
    curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/tables/'))
  ret = jsonlite::fromJSON(rawToChar(sql_req$content))[['success']] %>% {ifelse(is.null(.),F,.)}
  return(ret)
}


# onkostar ----------------------------------------------------------------

#'\code{seatable_to_onkostar} get table from seatable.tmo-heidelberg.de and send it as a property catalog to onkostar
#'@param group description
#'@param base description
#'@param table description
#'@param view description
#'@param cat_name name of the catalog
#'@param cat_description description of the catalog
#'@param cat_note additive info for the catalog
#'@param cat_overwrite overwrite catalog? ('false', 'version', 'all' Default:'false')
#'@param cat_dataFormGuid GUID of the data form in Onkostar that can be used to download the current property catalog. Necessary when using cat_overwrite="version"
#'@param cat_version_del '|'-separated list of versions that should be removed when overwrite="version"
#'@param cat_inact_non_st_versions After uploading Seatable versions - should I inactivate all other versions? Only valid if cat_overwrite="version" (default:T)
#'@param file_url file_url (optional)
#'@param file_keep keep XML file? (default: false, always false if file_url not defined)
#'@param upload_to_onkostar Upload to Onkostar2 ? (default: true)
#'@return data frame
#'@export

seatable_to_onkostar = function (group, base, table, view = "onkostar", cat_folder="Seatable", cat_name, cat_description, cat_note, cat_overwrite="false", cat_dataFormGuid, cat_version_del, cat_inact_non_st_versions=T, file_url, file_keep=F, upload_to_onkostar = T) {
  url = "https://seatable.tmo-heidelberg.de/"
  user = TMO$dkfz_login
  password = TMO$dkfz_password
  reference_tables=F
  if (missing(cat_dataFormGuid)) cat_dataFormGuid = NA
  if (missing(cat_version_del)) cat_version_del = NA
  if (missing(file_url)) file_url = NA
  if (is.na(file_url)) file_keep=F
  if (cat_inact_non_st_versions=="true") cat_inact_non_st_versions=T
  if (cat_overwrite!='all' & cat_overwrite!='version') cat_overwrite='false' # if seafile roe has been created and cat_overwrite has never been clickes, n8n will hand over a null value which should be interpreted as "false"
  file_url = coalesce(file_url, tempfile(pattern = 'file', fileext = ".xml"))
  sf_df = seatable_get_table(group=group, base=base, table=table, view=view, flatten_multi_choice = T) %>%
    select(matches('@onkostar$')) %>%
    rename_with(~str_remove(.,'@onkostar$')) %>%
    separate(version, into=c('versionSuffix','versionDescription','versionValidFrom','versionActive'), sep = '~', fill = "right") %>%
    mutate(across(everything(), trimws)) %>%
    mutate(category = str_replace_all(category, '#', ', '))
  sf_cols_missing = c('id', 'descriptionShort','descriptionLong','synonyms','note','position','category','categoryDescription','versionDescription','versionValidFrom','versionActive') %>%
    setdiff(names(sf_df)) %>%
    {setNames(as.data.frame(matrix(ncol=length(.), nrow=1, data = '')),.)}
  sf_df = sf_df %>% bind_cols(sf_cols_missing) %>%
    mutate(
      category_description = categoryDescription,
      version=if_else(str_detect(versionSuffix,'\\.'),versionSuffix,paste0(cat_name,'.',versionSuffix)),
      version_description = coalesce(versionDescription,'no description'),
      version_valid_from = coalesce(versionValidFrom,as.character(Sys.Date())),
      version_active = coalesce(versionActive,'true'),
      description_short = coalesce(descriptionShort,''),
      description_long = coalesce(descriptionLong,''),
      position = coalesce(as.integer(position), row_number()),
      synonyms = coalesce(synonyms,''),
      note = coalesce(note,'')
    ) %>% select(-versionSuffix, -categoryDescription, -versionDescription, -versionValidFrom, -versionActive, -descriptionShort, -descriptionLong)
  create_onkostar_property_cat_xml(
    cat = sf_df,
    cat_folder = cat_folder,
    cat_name = cat_name,
    cat_description = cat_description,
    cat_note = cat_note,
    file_url = file_url
  )
  if (upload_to_onkostar) {
    wlog(paste0("Upoading XML file to Onkostar: ",file_url))
    upload_onkostar_property_cat_xml(file_url = file_url, overwrite = cat_overwrite, dataFormGuid = cat_dataFormGuid, version_del = cat_version_del, inact_non_st_versions=cat_inact_non_st_versions)
  }
  if (!(file_keep)) {
    wlog(paste0("Deleting XML file: ",file_url))
    file.remove(file_url)
  }
}


#'\code{seatable_create_user_token} returns a token required for the API usage of seatable
#'@param url the url of the seatable instance; default: "https://seatable.tmo-heidelberg.de/"
#'@param user the AD user name
#'@param password the AD password
#'@return token
#'@export

seatable_create_user_token = function(url = "https://seatable.tmo-heidelberg.de/", user, password) {
  user_token = httr2::request(paste0(url,'api2/auth-token/')) %>%
    httr2::req_body_form(username = user, password = password) %>%
    httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_json() %>%
    {.$token}

  return(user_token)
}


#'\code{seatable_rename_base} returns a token required for the API usage of seatable
#'@param url the url of the seatable instance; default: "https://seatable.tmo-heidelberg.de/"
#'@param workspace_id the id of the workspace the base is located in
#'@param name current name of the base
#'@param new_name new name of the base
#'@param token token requried to use the API
#'@return return value of the API request
#'@export

seatable_rename_base = function(base_url = "https://seatable.tmo-heidelberg.de/", workspace_id, name, new_name, token) {
  url = paste(base_url, "api/v2.1/workspace/", workspace_id, "/dtable/", sep = "")
  sql_req =
    curl::new_handle() %>%
    curl::handle_setheaders(
      Authorization = paste("Token", token),
      `Accept` = "application/json"
    ) %>%
    curl::handle_setform(name = name,
                         new_name = new_name
    ) %>%
    curl::handle_setopt(
      CUSTOMREQUEST = "PUT",
      URL = url,
      FOLLOWLOCATION = 1L
    ) %>%
    curl::curl_fetch_memory(url = url)
  return(sql_req)
}



# internal functions ------------------------------------------------------
seatable_get_base_df = function (group, base, url, user, password) {
  user_token = seatable_create_user_token(url, user, password)

  workspaces_list = httr2::request(paste0(url,'api/v2.1/workspaces/')) %>%
    httr2::req_headers(Authorization = paste("Token",user_token)) %>%
    httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_json() %>%
    {.[[1]]}

  workspace_id = tibble(name=map_chr(workspaces_list, ~.x$name), id=map_chr(workspaces_list, ~.x$id)) %>%
    filter(name==group) %>% {.$id}

  base_df = httr2::request(paste0(url,'api/v2.1/workspace/',workspace_id,'/dtable/',base,'/access-token/')) %>%
    httr2::req_headers(Authorization = paste("Token",user_token)) %>%
    httr2::req_options(ssl_verifypeer = 0) %>% httr2::req_perform() %>% httr2::resp_body_json() %>% as_tibble() %>%
    mutate(workspace_id=workspace_id)

  return(base_df)
}

seatable_upload_csv_10000 = function (csv_file, group, base, table, url, user, password, mode, overwrite) {
  base_df = seatable_get_base_df(group = group, base = base, url = url, user = user, password = password)

  base_tables = curl::new_handle() %>%
    curl::handle_setheaders(Authorization = paste("Token", base_df$access_token)) %>%
    curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/metadata/')) %>%
    .$content %>% rawToChar() %>% jsonlite::fromJSON() %>%
    {.$metadata$tables$name}

  if (table %in% base_tables & mode!='append') {
    wlog(paste0("Cannot insert table '",table,"' in base '",base,"' in group '",group,"' because it already exists!"), type = "error")
    ret = F
  } else {
    if (mode=='upload') {
      tsv_upload_req = curl::new_handle() %>%
        curl::handle_setheaders(Authorization = paste("Token", base_df$access_token), enctype = "multipart/form-data") %>%
        curl::handle_setform(csv_file=curl::form_file(csv_file), table_name=table, lang='de-DE') %>%
        curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/import-csv/'))
      rows_inserted = jsonlite::fromJSON(rawToChar(tsv_upload_req$content))[['inserted_row_count']]
      wlog(paste0("Inserted (",mode,') ', rows_inserted," row(s) from ",csv_file," into table '",table,"' in base '",base,"' in group '",group,"'"))
      ret = rows_inserted
    } else {
      tsv_upload_req = curl::new_handle() %>%
        curl::handle_setheaders(Authorization = paste("Token", base_df$access_token), enctype = "multipart/form-data") %>%
        curl::handle_setform(csv_file=curl::form_file(csv_file), table_name=table) %>%
        curl::curl_fetch_memory(url = paste0(url,'dtable-server/api/v1/dtables/',base_df$dtable_uuid,'/append-csv/'))
      wlog(paste0("Appended row(s) from ",csv_file," into table '",table,"' in base '",base,"' in group '",group,"'"))
      ret = -1
    }
  }
  return(ret)
}

