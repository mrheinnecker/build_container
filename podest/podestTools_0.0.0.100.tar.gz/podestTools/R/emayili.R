#'\code{send_mail_dkfz} send mail via dkfz SMTP server
#'@param to recipient email address
#'@param cc cc recipient email address
#'@param subject email subject
#'@param text email body (text, e.g. "Hello, this is my mail!"). Use this or "html"...
#'@param html email body (HTML, e.g. "<html><body>Hello, this is my <b>mail</b>!</body></html>"). Use this or "text"...
#'@param dkfz_email dkfz sender email address, e.g. firstname.lastname@nct-heidelberg.de (default: TMO$dkfz_email)
#'@param dkfz_user dkfz user for SMTP authentication (default: TMO$dkfz_user)
#'@param dkfz_password dkfz password for SMTP authentication (default: TMO$dkfz_password)
#'@param attachment_file file which shall be attached to the email (default: /path/to/your/file.txt)
#'@export
send_mail_dkfz <- function(to, cc, subject, text, html, dkfz_email = TMO$dkfz_email, dkfz_login = TMO$dkfz_login, dkfz_password = TMO$dkfz_password, attachment_file) {
  if(missing(cc)) {
    email <- emayili::envelope(
      to = to,
      from = dkfz_email,
      subject = subject
    )
  } else {
    email <- emayili::envelope(
      to = to,
      cc = cc,
      from = dkfz_email,
      subject = subject
    )
  }


  if (!missing(html)) { email = emayili::html(email,html) }
  else if (!missing(text)) { email = emayili::text(email,text)}

  if(!missing(attachment_file)) {
    email = email %>% emayili::attachment(attachment_file)
  }

  smtp <- emayili::server(host = "mailhost2.dkfz-heidelberg.de",
                          port = 25,
                 username = paste0('ad\\',dkfz_login),
                 password = dkfz_password)
  smtp(email, verbose = T)
}
