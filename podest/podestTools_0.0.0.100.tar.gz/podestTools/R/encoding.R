#'\code{dec2chars} transform a decimal to a string based on a given char set
#'@param d decimal to transfrom
#'@param chars char set, e.g. "0123456789abcdefghijklmnopqrstuvwxyz"
#'@param min_length add trailing char set "zeros" to the start up to min_length
#'@return boolean vector
#'@export
dec2chars = function(d, chars="0123456789abcdefghijklmnopqrstuvwxyz", min_length) {
  cl = str_length(chars)
  c = ""
  n = substring(chars,1,1)
  if (d==0) {c=n}
  else {
    while (d>0) {
      mod = d %% cl
      d = d %/% cl
      c=paste0(substring(chars,mod+1,mod+1),c)
    }
  }
  if (!missing(min_length)) c = paste0(c(rep(n,min_length-str_length(c)),c), collapse = "")
  return(c)
}

