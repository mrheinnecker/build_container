# podestTools
This package contains R tools that are used accross the different podest packages.

## Install library in R
To install the library, just enter

```R
library(devtools)
devtools::install_git(url="https://USER:YOUR_PERSONAL_ACCESS_TOKEN@git.dkfz.de/hd02/podestTools.git", upgrade = F)
```

